"""
SearchBot AI — Motore Intelligenza Artificiale con Groq
Gestisce chat, analisi risultati e decisioni di ricerca automatica.
"""

import os
import json
import time
import logging
import re

logger = logging.getLogger(__name__)

# Tenta di importare Groq SDK
try:
    from groq import Groq
    GROQ_AVAILABLE = True
except ImportError:
    GROQ_AVAILABLE = False
    logger.warning("SDK Groq non installato. Installa con: pip install groq")


class AIEngine:
    """Motore AI per SearchBot basato su Groq (Llama 3)."""

    # Modello preferito (veloce e potente)
    DEFAULT_MODEL = "llama-3.3-70b-versatile"
    FALLBACK_MODEL = "llama-3.1-8b-instant"

    # System prompt principale
    SYSTEM_PROMPT = """Sei SearchBot AI, un assistente di ricerca intelligente in italiano.

Il tuo compito è aiutare l'utente a trovare informazioni, analizzare risultati di ricerca e rispondere alle domande.

Regole:
- Rispondi SEMPRE in italiano, a meno che l'utente non chieda esplicitamente in un'altra lingua
- Sii conciso ma completo
- Quando analizzi risultati di ricerca, cita le fonti con [titolo](url)
- Usa formattazione markdown: **grassetto**, *corsivo*, elenchi puntati, ecc.
- Se non sei sicuro di qualcosa, dillo chiaramente
- Per domande che richiedono informazioni aggiornate, suggerisci di abilitare la ricerca Google
"""

    SEARCH_DECISION_PROMPT = """Analizza il messaggio dell'utente e decidi se richiede una ricerca web su Google.

Rispondi SOLO con un JSON valido in questo formato:
{"needs_search": true/false, "search_query": "query ottimizzata per Google oppure null", "reason": "breve motivo"}

Regole:
- needs_search = true se: l'utente chiede informazioni specifiche, notizie, fatti, dati, confronti, prodotti, persone, eventi
- needs_search = false se: saluti, domande su di te, richieste di spiegazione di concetti generali, calcoli semplici, programmazione
- search_query deve essere una query ottimizzata per Google (non la domanda intera dell'utente)

Messaggio utente: """

    ANALYSIS_PROMPT = """Analizza questi risultati di ricerca Google e fornisci una risposta completa alla domanda dell'utente.

Domanda dell'utente: {query}

Risultati di ricerca:
{results}

Regole:
- Sintetizza le informazioni dai risultati in una risposta chiara e utile
- Cita le fonti usando il formato [titolo](url) quando fai riferimento a informazioni specifiche
- Se i risultati non rispondono alla domanda, dillo chiaramente
- Organizza la risposta con punti chiave se ci sono molte informazioni
- Rispondi in italiano
"""

    def __init__(self):
        """Inizializza il motore AI."""
        self.api_key = os.environ.get("GROQ_API_KEY", "")
        self.client = None
        self.model = self.DEFAULT_MODEL
        self._initialized = False

        if self.api_key and GROQ_AVAILABLE:
            try:
                self.client = Groq(api_key=self.api_key)
                self._initialized = True
                logger.info(f"AI Engine inizializzato con modello {self.model}")
            except Exception as e:
                logger.error(f"Errore inizializzazione Groq: {e}")
        elif not GROQ_AVAILABLE:
            logger.warning("Groq SDK non disponibile")
        else:
            logger.warning("GROQ_API_KEY non configurata")

    @property
    def is_available(self):
        """Verifica se l'AI è disponibile."""
        return self._initialized and self.client is not None

    def _call_groq(self, messages, temperature=0.7, max_tokens=2048):
        """
        Effettua una chiamata all'API Groq.
        
        Args:
            messages: Lista di messaggi nel formato OpenAI
            temperature: Creatività (0-1)
            max_tokens: Lunghezza massima risposta
            
        Returns:
            str: Risposta dell'AI
        """
        if not self.is_available:
            return None

        try:
            response = self.client.chat.completions.create(
                model=self.model,
                messages=messages,
                temperature=temperature,
                max_tokens=max_tokens,
                stream=False,
            )
            return response.choices[0].message.content

        except Exception as e:
            error_msg = str(e)
            logger.error(f"Errore Groq API: {error_msg}")

            # Se il modello principale fallisce, prova il fallback
            if self.model == self.DEFAULT_MODEL:
                logger.info(f"Tentativo con modello fallback: {self.FALLBACK_MODEL}")
                try:
                    self.model = self.FALLBACK_MODEL
                    response = self.client.chat.completions.create(
                        model=self.model,
                        messages=messages,
                        temperature=temperature,
                        max_tokens=max_tokens,
                        stream=False,
                    )
                    result = response.choices[0].message.content
                    # Ripristina il modello principale per la prossima chiamata
                    self.model = self.DEFAULT_MODEL
                    return result
                except Exception as e2:
                    self.model = self.DEFAULT_MODEL
                    logger.error(f"Anche il modello fallback ha fallito: {e2}")

            return None

    def chat(self, user_message, conversation_history=None):
        """
        Gestisce un messaggio di chat.
        
        Args:
            user_message: Messaggio dell'utente
            conversation_history: Lista di messaggi precedenti [{role, content}]
            
        Returns:
            dict: {success, response, error}
        """
        if not self.is_available:
            return {
                "success": False,
                "response": None,
                "error": "AI non disponibile. Verifica che GROQ_API_KEY sia configurata."
            }

        messages = [{"role": "system", "content": self.SYSTEM_PROMPT}]

        # Aggiungi storico conversazione (ultime 10 coppie)
        if conversation_history:
            # Limita a ultimi 20 messaggi per non superare limiti token
            recent = conversation_history[-20:]
            for msg in recent:
                messages.append({
                    "role": msg["role"],
                    "content": msg["content"]
                })

        messages.append({"role": "user", "content": user_message})

        response = self._call_groq(messages)

        if response:
            return {
                "success": True,
                "response": response,
                "error": None
            }
        else:
            return {
                "success": False,
                "response": None,
                "error": "Errore nella generazione della risposta AI."
            }

    def should_search(self, user_message):
        """
        Decide se il messaggio dell'utente richiede una ricerca web.
        
        Args:
            user_message: Messaggio dell'utente
            
        Returns:
            dict: {needs_search, search_query, reason}
        """
        if not self.is_available:
            return {"needs_search": False, "search_query": None, "reason": "AI non disponibile"}

        messages = [
            {"role": "system", "content": "Rispondi SOLO con JSON valido, nient'altro."},
            {"role": "user", "content": self.SEARCH_DECISION_PROMPT + user_message}
        ]

        response = self._call_groq(messages, temperature=0.1, max_tokens=200)

        if response:
            try:
                # Pulizia: estrai JSON dalla risposta
                json_match = re.search(r'\{[^}]+\}', response, re.DOTALL)
                if json_match:
                    result = json.loads(json_match.group())
                    return {
                        "needs_search": result.get("needs_search", False),
                        "search_query": result.get("search_query"),
                        "reason": result.get("reason", "")
                    }
            except (json.JSONDecodeError, AttributeError) as e:
                logger.warning(f"Errore parsing decisione ricerca: {e}")

        return {"needs_search": False, "search_query": None, "reason": "Errore analisi"}

    def analyze_results(self, query, search_results, conversation_history=None):
        """
        Analizza i risultati di ricerca e genera una risposta intelligente.
        
        Args:
            query: Query originale dell'utente
            search_results: Lista di risultati [{title, url, description}]
            conversation_history: Storico conversazione opzionale
            
        Returns:
            dict: {success, response, error}
        """
        if not self.is_available:
            return {
                "success": False,
                "response": None,
                "error": "AI non disponibile."
            }

        # Formatta i risultati per l'AI
        results_text = ""
        for i, r in enumerate(search_results[:10], 1):
            results_text += f"\n{i}. **{r.get('title', 'N/A')}**\n"
            results_text += f"   URL: {r.get('url', 'N/A')}\n"
            results_text += f"   Descrizione: {r.get('description', 'N/A')}\n"

        analysis_prompt = self.ANALYSIS_PROMPT.format(
            query=query,
            results=results_text
        )

        messages = [{"role": "system", "content": self.SYSTEM_PROMPT}]

        if conversation_history:
            recent = conversation_history[-10:]
            for msg in recent:
                messages.append({"role": msg["role"], "content": msg["content"]})

        messages.append({"role": "user", "content": analysis_prompt})

        response = self._call_groq(messages, max_tokens=3000)

        if response:
            return {
                "success": True,
                "response": response,
                "error": None
            }
        else:
            return {
                "success": False,
                "response": None,
                "error": "Errore nell'analisi dei risultati."
            }

    def get_status(self):
        """Restituisce lo stato del motore AI."""
        return {
            "available": self.is_available,
            "model": self.model,
            "groq_sdk": GROQ_AVAILABLE,
            "api_key_set": bool(self.api_key),
        }


# Istanza globale (singleton)
_engine = None


def get_ai_engine():
    """Restituisce l'istanza singleton del motore AI."""
    global _engine
    if _engine is None:
        _engine = AIEngine()
    return _engine
