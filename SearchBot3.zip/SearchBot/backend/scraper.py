"""
SearchBot — Modulo Scraper Google
Cerca su Google e restituisce i risultati con titolo, URL e descrizione.
"""

import requests
from bs4 import BeautifulSoup
import random
import time
import urllib.parse
import logging

logger = logging.getLogger(__name__)

# Lista di User-Agent per rotazione
USER_AGENTS = [
    "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/125.0.0.0 Safari/537.36",
    "Mozilla/5.0 (X11; Linux x86_64; rv:128.0) Gecko/20100101 Firefox/128.0",
    "Mozilla/5.0 (X11; Ubuntu; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36",
    "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/123.0.0.0 Safari/537.36 Edg/123.0.0.0",
    "Mozilla/5.0 (X11; Debian; Linux x86_64; rv:127.0) Gecko/20100101 Firefox/127.0",
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/125.0.0.0 Safari/537.36",
    "Mozilla/5.0 (Macintosh; Intel Mac OS X 14_5) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/125.0.0.0 Safari/537.36",
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:128.0) Gecko/20100101 Firefox/128.0",
]

# Lingue per le ricerche
ACCEPT_LANGUAGES = [
    "it-IT,it;q=0.9,en-US;q=0.8,en;q=0.7",
    "en-US,en;q=0.9",
    "it-IT,it;q=0.8,en;q=0.6",
]


def _get_headers():
    """Genera headers randomici per le richieste."""
    return {
        "User-Agent": random.choice(USER_AGENTS),
        "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8",
        "Accept-Language": random.choice(ACCEPT_LANGUAGES),
        "Accept-Encoding": "gzip, deflate",
        "DNT": "1",
        "Connection": "keep-alive",
        "Upgrade-Insecure-Requests": "1",
        "Cache-Control": "max-age=0",
    }


def _parse_google_results(html, num_results=10):
    """
    Analizza l'HTML di Google e estrae i risultati.
    
    Args:
        html: HTML della pagina di risultati Google
        num_results: Numero massimo di risultati da estrarre
    
    Returns:
        Lista di dict con {title, url, description, position}
    """
    soup = BeautifulSoup(html, "lxml")
    results = []
    position = 1

    # Selettori principali per i risultati Google
    search_results = soup.select("div.g")

    if not search_results:
        # Fallback: prova altri selettori
        search_results = soup.select("div[data-sokoban-container]")

    if not search_results:
        # Ulteriore fallback
        search_results = soup.find_all("div", class_="tF2Cxc")

    for result in search_results:
        if position > num_results:
            break

        # Estrai titolo
        title_elem = result.select_one("h3")
        if not title_elem:
            continue
        title = title_elem.get_text(strip=True)

        # Estrai URL
        link_elem = result.select_one("a[href]")
        if not link_elem:
            continue
        url = link_elem.get("href", "")

        # Filtra URL non validi
        if not url.startswith("http"):
            continue

        # Filtra risultati Google interni
        if "google.com/search" in url or "accounts.google" in url:
            continue

        # Estrai descrizione
        description = ""
        desc_selectors = [
            "div.VwiC3b",
            "span.aCOpRe",
            "div[data-sncf]",
            "div.IsZvec",
        ]
        for selector in desc_selectors:
            desc_elem = result.select_one(selector)
            if desc_elem:
                description = desc_elem.get_text(strip=True)
                break

        if not description:
            # Fallback: prendi il testo dal contenitore
            spans = result.find_all("span")
            for span in spans:
                text = span.get_text(strip=True)
                if len(text) > 40 and text != title:
                    description = text
                    break

        results.append({
            "title": title,
            "url": url,
            "description": description[:500] if description else "Nessuna descrizione disponibile",
            "position": position,
        })
        position += 1

    return results


def search_google(query, num_results=10, lang="it"):
    """
    Esegue una ricerca su Google tramite scraping.
    
    Args:
        query: La query di ricerca
        num_results: Numero di risultati desiderati (max 20)
        lang: Lingua dei risultati (default: italiano)
    
    Returns:
        dict con {success, results, error, method}
    """
    num_results = min(num_results, 20)

    # Metodo 1: Scraping diretto di Google
    try:
        results = _scrape_google_direct(query, num_results, lang)
        if results:
            return {
                "success": True,
                "results": results,
                "error": None,
                "method": "scraping_diretto"
            }
    except Exception as e:
        logger.warning(f"Scraping diretto fallito: {e}")

    # Delay prima del retry
    time.sleep(random.uniform(1, 2))

    # Metodo 2: Fallback con googlesearch-python
    try:
        results = _search_with_library(query, num_results, lang)
        if results:
            return {
                "success": True,
                "results": results,
                "error": None,
                "method": "googlesearch_lib"
            }
    except Exception as e:
        logger.warning(f"googlesearch-python fallito: {e}")

    # Metodo 3: DuckDuckGo come ultimo fallback
    try:
        results = _scrape_duckduckgo(query, num_results)
        if results:
            return {
                "success": True,
                "results": results,
                "error": None,
                "method": "duckduckgo_fallback"
            }
    except Exception as e:
        logger.warning(f"DuckDuckGo fallback fallito: {e}")

    return {
        "success": False,
        "results": [],
        "error": "Tutti i metodi di ricerca hanno fallito. Riprova tra qualche minuto.",
        "method": None
    }


def _scrape_google_direct(query, num_results, lang):
    """Scraping diretto della pagina di ricerca Google."""
    encoded_query = urllib.parse.quote_plus(query)
    url = f"https://www.google.com/search?q={encoded_query}&num={num_results + 5}&hl={lang}&gl={lang}"

    # Delay randomico per sembrare umano
    time.sleep(random.uniform(0.5, 1.5))

    session = requests.Session()
    headers = _get_headers()

    response = session.get(url, headers=headers, timeout=15)
    response.raise_for_status()

    if "unusual traffic" in response.text.lower() or response.status_code == 429:
        raise Exception("Google ha rilevato traffico insolito")

    results = _parse_google_results(response.text, num_results)
    return results if results else None


def _search_with_library(query, num_results, lang):
    """Usa la libreria googlesearch-python come fallback."""
    try:
        from googlesearch import search as gsearch

        results = []
        position = 1

        for url in gsearch(query, num_results=num_results, lang=lang, sleep_interval=1):
            results.append({
                "title": _extract_title_from_url(url),
                "url": url,
                "description": "Risultato trovato tramite ricerca alternativa",
                "position": position,
            })
            position += 1

            if position > num_results:
                break

        return results if results else None

    except ImportError:
        logger.warning("googlesearch-python non installato")
        return None


def _scrape_duckduckgo(query, num_results):
    """Usa DuckDuckGo HTML come fallback finale."""
    encoded_query = urllib.parse.quote_plus(query)
    url = f"https://html.duckduckgo.com/html/?q={encoded_query}"

    time.sleep(random.uniform(0.5, 1.5))

    headers = _get_headers()
    response = requests.get(url, headers=headers, timeout=15)
    response.raise_for_status()

    soup = BeautifulSoup(response.text, "lxml")
    results = []
    position = 1

    for result in soup.select(".result"):
        if position > num_results:
            break

        title_elem = result.select_one(".result__title a")
        if not title_elem:
            continue

        title = title_elem.get_text(strip=True)
        href = title_elem.get("href", "")

        # DuckDuckGo redirige tramite i propri URL
        if "duckduckgo.com" in href:
            parsed = urllib.parse.urlparse(href)
            params = urllib.parse.parse_qs(parsed.query)
            href = params.get("uddg", [href])[0]

        desc_elem = result.select_one(".result__snippet")
        description = desc_elem.get_text(strip=True) if desc_elem else ""

        if href.startswith("http"):
            results.append({
                "title": title,
                "url": href,
                "description": description or "Nessuna descrizione disponibile",
                "position": position,
            })
            position += 1

    return results if results else None


def _extract_title_from_url(url):
    """Estrae un titolo leggibile dall'URL."""
    parsed = urllib.parse.urlparse(url)
    domain = parsed.netloc.replace("www.", "")

    path = parsed.path.strip("/")
    if path:
        # Converti path in titolo leggibile
        parts = path.split("/")
        last_part = parts[-1].replace("-", " ").replace("_", " ")
        # Rimuovi estensioni
        last_part = last_part.rsplit(".", 1)[0]
        if last_part:
            return f"{last_part.title()} — {domain}"

    return domain
