"""
SearchBot AI — Server Flask Principale
API REST per la ricerca Google con IA e dashboard web.
"""

import os
import sys
import json
import logging
from datetime import datetime

from flask import Flask, request, jsonify, send_from_directory

from database import (
    init_db, save_search, get_history, get_search_by_id, delete_search,
    clear_history, get_stats, create_conversation, get_conversations,
    get_conversation, delete_conversation, save_message,
    get_conversation_messages, update_conversation_title
)
from scraper import search_google
from ai_engine import get_ai_engine

# Configurazione logging
logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [%(levelname)s] %(name)s: %(message)s",
    handlers=[
        logging.StreamHandler(sys.stdout),
        logging.FileHandler("searchbot.log", encoding="utf-8"),
    ]
)
logger = logging.getLogger("SearchBot")

# Inizializza Flask
app = Flask(__name__, static_folder="static", static_url_path="")

# Configurazione
app.config["JSON_AS_ASCII"] = False
app.config["JSON_SORT_KEYS"] = False


# ─── Inizializzazione ────────────────────────────────────────────────

@app.before_request
def before_first_request():
    """Inizializza il database alla prima richiesta."""
    if not hasattr(app, "_db_initialized"):
        init_db()
        app._db_initialized = True
        logger.info("Database inizializzato")


# ─── Routes Statiche ─────────────────────────────────────────────────

@app.route("/")
def index():
    """Serve la dashboard principale."""
    return send_from_directory("static", "index.html")


# ─── API Chat AI ─────────────────────────────────────────────────────

@app.route("/api/chat", methods=["POST"])
def api_chat():
    """
    Endpoint principale chat AI.
    
    Body JSON:
        message (str): Messaggio dell'utente
        conversation_id (int, opzionale): ID conversazione esistente
        auto_search (bool, opzionale): Abilita ricerca automatica (default: True)
        lang (str, opzionale): Lingua ricerca (default: "it")
    
    Returns:
        JSON con risposta AI, eventuali risultati di ricerca
    """
    data = request.get_json()

    if not data or not data.get("message"):
        return jsonify({"success": False, "error": "Messaggio mancante"}), 400

    user_message = data["message"].strip()
    if len(user_message) < 1:
        return jsonify({"success": False, "error": "Messaggio troppo corto"}), 400

    conversation_id = data.get("conversation_id")
    auto_search = data.get("auto_search", True)
    lang = data.get("lang", "it")

    ai = get_ai_engine()

    # Verifica disponibilità AI
    if not ai.is_available:
        return jsonify({
            "success": False,
            "error": "AI non disponibile. Verifica che GROQ_API_KEY sia configurata."
        }), 503

    # Crea o recupera conversazione
    if not conversation_id:
        conversation_id = create_conversation()
        # Usa le prime parole come titolo
        title = user_message[:50] + ("..." if len(user_message) > 50 else "")
        update_conversation_title(conversation_id, title)

    # Salva messaggio utente
    save_message(conversation_id, "user", user_message)

    # Recupera storico conversazione
    history = get_conversation_messages(conversation_id, limit=20)
    conversation_history = [
        {"role": m["role"], "content": m["content"]}
        for m in history[:-1]  # Escludi l'ultimo (appena salvato)
    ]

    search_data = None
    search_id = None

    # Decide se serve una ricerca
    if auto_search:
        decision = ai.should_search(user_message)
        logger.info(f"Decisione ricerca: {decision}")

        if decision["needs_search"] and decision["search_query"]:
            # Esegui ricerca Google
            search_query = decision["search_query"]
            search_result = search_google(search_query, num_results=8, lang=lang)

            if search_result["success"] and search_result["results"]:
                # Salva ricerca nel database
                search_id = save_search(search_query, search_result["results"])
                search_data = {
                    "query": search_query,
                    "results": search_result["results"],
                    "method": search_result["method"],
                }

                # Analizza risultati con AI
                analysis = ai.analyze_results(
                    user_message,
                    search_result["results"],
                    conversation_history
                )

                if analysis["success"]:
                    ai_response = analysis["response"]
                else:
                    # Fallback: rispondi senza analisi
                    chat_result = ai.chat(user_message, conversation_history)
                    ai_response = chat_result.get("response", "Mi dispiace, non sono riuscito a elaborare la risposta.")
            else:
                # Ricerca fallita, rispondi comunque con AI
                chat_result = ai.chat(user_message, conversation_history)
                ai_response = chat_result.get("response", "Mi dispiace, la ricerca non ha prodotto risultati.")
        else:
            # Non serve ricerca, rispondi direttamente
            chat_result = ai.chat(user_message, conversation_history)
            if chat_result["success"]:
                ai_response = chat_result["response"]
            else:
                return jsonify({
                    "success": False,
                    "error": chat_result["error"]
                }), 503
    else:
        # Ricerca disabilitata, solo chat
        chat_result = ai.chat(user_message, conversation_history)
        if chat_result["success"]:
            ai_response = chat_result["response"]
        else:
            return jsonify({
                "success": False,
                "error": chat_result["error"]
            }), 503

    # Salva risposta AI
    search_results_for_db = search_data["results"] if search_data else None
    save_message(conversation_id, "assistant", ai_response,
                 search_id=search_id, search_results=search_results_for_db)

    logger.info(f"Chat #{conversation_id}: '{user_message[:50]}' → risposta generata" +
                (f" (con ricerca: '{search_data['query']}')" if search_data else ""))

    return jsonify({
        "success": True,
        "conversation_id": conversation_id,
        "response": ai_response,
        "search": search_data,
        "timestamp": datetime.utcnow().isoformat(),
    })


@app.route("/api/analyze", methods=["POST"])
def api_analyze():
    """
    Analizza risultati di ricerca esistenti con AI.
    
    Body JSON:
        search_id (int): ID della ricerca da analizzare
        question (str, opzionale): Domanda specifica sui risultati
    """
    data = request.get_json()

    if not data or not data.get("search_id"):
        return jsonify({"success": False, "error": "search_id mancante"}), 400

    search = get_search_by_id(data["search_id"])
    if not search:
        return jsonify({"success": False, "error": "Ricerca non trovata"}), 404

    ai = get_ai_engine()
    if not ai.is_available:
        return jsonify({"success": False, "error": "AI non disponibile"}), 503

    question = data.get("question", search["query"])
    analysis = ai.analyze_results(question, search["results"])

    if analysis["success"]:
        return jsonify({
            "success": True,
            "analysis": analysis["response"],
            "query": search["query"],
        })
    else:
        return jsonify({"success": False, "error": analysis["error"]}), 503


# ─── API Conversazioni ───────────────────────────────────────────────

@app.route("/api/conversations", methods=["GET"])
def api_conversations():
    """Restituisce la lista delle conversazioni."""
    limit = min(int(request.args.get("limit", 50)), 100)
    conversations = get_conversations(limit=limit)
    return jsonify({"success": True, "conversations": conversations})


@app.route("/api/conversations/<int:conv_id>", methods=["GET"])
def api_get_conversation(conv_id):
    """Restituisce una conversazione con i suoi messaggi."""
    conv = get_conversation(conv_id)
    if conv is None:
        return jsonify({"success": False, "error": "Conversazione non trovata"}), 404
    return jsonify({"success": True, "conversation": conv})


@app.route("/api/conversations/<int:conv_id>", methods=["DELETE"])
def api_delete_conversation(conv_id):
    """Elimina una conversazione."""
    deleted = delete_conversation(conv_id)
    if deleted:
        return jsonify({"success": True, "message": "Conversazione eliminata"})
    return jsonify({"success": False, "error": "Conversazione non trovata"}), 404


# ─── API AI Status ───────────────────────────────────────────────────

@app.route("/api/ai/status", methods=["GET"])
def api_ai_status():
    """Restituisce lo stato del motore AI."""
    ai = get_ai_engine()
    return jsonify({
        "success": True,
        "ai": ai.get_status()
    })


# ─── API Ricerca ──────────────────────────────────────────────────────

@app.route("/api/search", methods=["POST"])
def api_search():
    """
    Esegue una ricerca su Google.
    
    Body JSON:
        query (str): La query di ricerca
        num_results (int, opzionale): Numero di risultati (default: 10, max: 20)
        lang (str, opzionale): Lingua (default: "it")
    
    Returns:
        JSON con risultati della ricerca
    """
    data = request.get_json()

    if not data or not data.get("query"):
        return jsonify({"success": False, "error": "Query mancante"}), 400

    query = data["query"].strip()
    if len(query) < 2:
        return jsonify({"success": False, "error": "Query troppo corta (min 2 caratteri)"}), 400

    if len(query) > 200:
        return jsonify({"success": False, "error": "Query troppo lunga (max 200 caratteri)"}), 400

    num_results = min(int(data.get("num_results", 10)), 20)
    lang = data.get("lang", "it")

    logger.info(f"Ricerca: '{query}' (num={num_results}, lang={lang})")

    # Esegui la ricerca
    search_result = search_google(query, num_results=num_results, lang=lang)

    if search_result["success"]:
        # Salva nello storico
        search_id = save_search(query, search_result["results"])
        logger.info(f"Ricerca #{search_id}: {len(search_result['results'])} risultati trovati ({search_result['method']})")

        return jsonify({
            "success": True,
            "search_id": search_id,
            "query": query,
            "results": search_result["results"],
            "results_count": len(search_result["results"]),
            "method": search_result["method"],
            "timestamp": datetime.utcnow().isoformat(),
        })
    else:
        logger.warning(f"Ricerca fallita: '{query}' — {search_result['error']}")
        return jsonify({
            "success": False,
            "error": search_result["error"],
        }), 503


# ─── API Storico ──────────────────────────────────────────────────────

@app.route("/api/history", methods=["GET"])
def api_history():
    """
    Restituisce lo storico delle ricerche.
    
    Query params:
        limit (int): Numero massimo (default: 50)
        offset (int): Offset per paginazione (default: 0)
    """
    limit = min(int(request.args.get("limit", 50)), 100)
    offset = int(request.args.get("offset", 0))

    history = get_history(limit=limit, offset=offset)
    return jsonify({
        "success": True,
        "history": history,
        "count": len(history),
    })


@app.route("/api/history/<int:search_id>", methods=["GET"])
def api_get_search(search_id):
    """Restituisce una ricerca specifica."""
    search = get_search_by_id(search_id)
    if search is None:
        return jsonify({"success": False, "error": "Ricerca non trovata"}), 404
    return jsonify({"success": True, "search": search})


@app.route("/api/history/<int:search_id>", methods=["DELETE"])
def api_delete_search(search_id):
    """Elimina una ricerca dallo storico."""
    deleted = delete_search(search_id)
    if deleted:
        return jsonify({"success": True, "message": "Ricerca eliminata"})
    return jsonify({"success": False, "error": "Ricerca non trovata"}), 404


@app.route("/api/history/clear", methods=["DELETE"])
def api_clear_history():
    """Elimina tutto lo storico."""
    clear_history()
    return jsonify({"success": True, "message": "Storico eliminato"})


# ─── API Statistiche ─────────────────────────────────────────────────

@app.route("/api/stats", methods=["GET"])
def api_stats():
    """Restituisce statistiche generali."""
    stats = get_stats()
    return jsonify({"success": True, "stats": stats})


# ─── Health Check ─────────────────────────────────────────────────────

@app.route("/api/health", methods=["GET"])
def api_health():
    """Health check per monitoraggio."""
    ai = get_ai_engine()
    return jsonify({
        "status": "ok",
        "service": "SearchBot AI",
        "ai_available": ai.is_available,
        "timestamp": datetime.utcnow().isoformat(),
    })


# ─── Error Handlers ──────────────────────────────────────────────────

@app.errorhandler(404)
def not_found(e):
    return jsonify({"success": False, "error": "Endpoint non trovato"}), 404


@app.errorhandler(500)
def server_error(e):
    logger.error(f"Errore server: {e}")
    return jsonify({"success": False, "error": "Errore interno del server"}), 500


# ─── Main ─────────────────────────────────────────────────────────────

if __name__ == "__main__":
    init_db()
    ai = get_ai_engine()
    ai_status = "✅ AI disponibile" if ai.is_available else "⚠️ AI non disponibile (GROQ_API_KEY mancante)"
    logger.info(f"SearchBot AI avviato — http://0.0.0.0:5000 — {ai_status}")

    app.run(
        host="0.0.0.0",
        port=5000,
        debug=False,
    )
