/**
 * SearchBot AI — Frontend Application Logic
 * Gestisce chat AI, ricerche, storico, statistiche e interazioni UI.
 */

// ─── State ───────────────────────────────────────────────────────
const state = {
    currentTab: 'chat',
    isSearching: false,
    isChatting: false,
    lastQuery: '',
    lastResults: null,
    currentConversationId: null,
    aiAvailable: false,
};

// ─── DOM Elements ────────────────────────────────────────────────
const $ = (sel) => document.querySelector(sel);
const $$ = (sel) => document.querySelectorAll(sel);

const els = {
    // Chat
    chatInput: $('#chatInput'),
    chatSendBtn: $('#chatSendBtn'),
    chatMessages: $('#chatMessages'),
    chatWelcome: $('#chatWelcome'),
    typingIndicator: $('#typingIndicator'),
    typingText: $('#typingText'),
    autoSearchToggle: $('#autoSearchToggle'),
    newChatBtn: $('#newChatBtn'),
    conversationsList: $('#conversationsList'),
    // Search
    searchInput: $('#searchInput'),
    searchBtn: $('#searchBtn'),
    numResults: $('#numResults'),
    searchLang: $('#searchLang'),
    loadingContainer: $('#loadingContainer'),
    loadingSubtext: $('#loadingSubtext'),
    resultsArea: $('#resultsArea'),
    resultsGrid: $('#resultsGrid'),
    resultsTitle: $('#resultsTitle'),
    resultsMeta: $('#resultsMeta'),
    errorContainer: $('#errorContainer'),
    errorText: $('#errorText'),
    exportBtn: $('#exportBtn'),
    copyBtn: $('#copyBtn'),
    analyzeBtn: $('#analyzeBtn'),
    retryBtn: $('#retryBtn'),
    aiAnalysisArea: $('#aiAnalysisArea'),
    aiAnalysisContent: $('#aiAnalysisContent'),
    aiAnalysisClose: $('#aiAnalysisClose'),
    // History
    historyList: $('#historyList'),
    clearHistoryBtn: $('#clearHistoryBtn'),
    // Stats
    statsGrid: $('#statsGrid'),
    statSearches: $('#statSearches'),
    statResults: $('#statResults'),
    statConversations: $('#statConversations'),
    statAvg: $('#statAvg'),
    topQueriesList: $('#topQueriesList'),
    // Global
    toastContainer: $('#toastContainer'),
    bgParticles: $('#bgParticles'),
    aiStatus: $('#aiStatus'),
};

// ─── Initialize ──────────────────────────────────────────────────
document.addEventListener('DOMContentLoaded', () => {
    initParticles();
    initTabs();
    initChat();
    initSearch();
    initHistory();
    initExport();
    checkHealth();
    loadConversations();
});

// ─── Background Particles ────────────────────────────────────────
function initParticles() {
    const colors = ['rgba(99,102,241,0.3)', 'rgba(168,85,247,0.25)', 'rgba(236,72,153,0.2)'];
    for (let i = 0; i < 15; i++) {
        const particle = document.createElement('div');
        particle.className = 'particle';
        particle.style.cssText = `
            left: ${Math.random() * 100}%;
            width: ${2 + Math.random() * 4}px;
            height: ${2 + Math.random() * 4}px;
            background: ${colors[Math.floor(Math.random() * colors.length)]};
            animation-duration: ${10 + Math.random() * 20}s;
            animation-delay: ${Math.random() * 10}s;
        `;
        els.bgParticles.appendChild(particle);
    }
}

// ─── Tab Navigation ──────────────────────────────────────────────
function initTabs() {
    $$('.nav-tab').forEach(tab => {
        tab.addEventListener('click', () => {
            const tabName = tab.dataset.tab;
            switchTab(tabName);
        });
    });
}

function switchTab(tabName) {
    state.currentTab = tabName;

    // Update nav tabs
    $$('.nav-tab').forEach(t => t.classList.remove('active'));
    $(`.nav-tab[data-tab="${tabName}"]`).classList.add('active');

    // Update tab content
    $$('.tab-content').forEach(c => c.classList.remove('active'));
    $(`#tab${tabName.charAt(0).toUpperCase() + tabName.slice(1)}`).classList.add('active');

    // Load data for tab
    if (tabName === 'history') loadHistory();
    if (tabName === 'stats') loadStats();
    if (tabName === 'chat') els.chatInput.focus();
}

// ═══════════════════════════════════════════════════════════════
// CHAT AI
// ═══════════════════════════════════════════════════════════════

function initChat() {
    // Send button
    els.chatSendBtn.addEventListener('click', sendChatMessage);

    // Enter to send, Shift+Enter for new line
    els.chatInput.addEventListener('keydown', (e) => {
        if (e.key === 'Enter' && !e.shiftKey) {
            e.preventDefault();
            sendChatMessage();
        }
    });

    // Auto-resize textarea
    els.chatInput.addEventListener('input', () => {
        els.chatInput.style.height = 'auto';
        els.chatInput.style.height = Math.min(els.chatInput.scrollHeight, 120) + 'px';
    });

    // New chat button
    els.newChatBtn.addEventListener('click', startNewChat);

    // Suggestion chips
    $$('.suggestion-chip').forEach(chip => {
        chip.addEventListener('click', () => {
            els.chatInput.value = chip.dataset.query;
            sendChatMessage();
        });
    });

    // Auto focus
    setTimeout(() => els.chatInput.focus(), 300);
}

function startNewChat() {
    state.currentConversationId = null;
    els.chatMessages.innerHTML = '';
    els.chatMessages.style.display = 'none';
    els.chatWelcome.style.display = 'flex';
    els.chatInput.value = '';
    els.chatInput.focus();

    // Deselect sidebar items
    $$('.conv-item').forEach(c => c.classList.remove('active'));
}

async function sendChatMessage() {
    const message = els.chatInput.value.trim();
    if (!message || state.isChatting) return;

    state.isChatting = true;
    els.chatSendBtn.disabled = true;

    // Show chat area, hide welcome
    els.chatWelcome.style.display = 'none';
    els.chatMessages.style.display = 'flex';

    // Add user message
    appendMessage('user', message);

    // Clear input
    els.chatInput.value = '';
    els.chatInput.style.height = 'auto';

    // Show typing indicator
    showTyping('SearchBot sta pensando...');

    try {
        const response = await fetch('/api/chat', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
                message: message,
                conversation_id: state.currentConversationId,
                auto_search: els.autoSearchToggle.checked,
                lang: 'it',
            }),
        });

        const data = await response.json();
        hideTyping();

        if (data.success) {
            state.currentConversationId = data.conversation_id;

            // Add AI response with optional search results
            appendMessage('assistant', data.response, data.search);

            // Refresh sidebar
            loadConversations();
        } else {
            appendMessage('assistant', `⚠️ ${data.error || 'Errore nella risposta AI.'}`);
        }
    } catch (err) {
        hideTyping();
        appendMessage('assistant', '⚠️ Errore di connessione al server. Verifica che il bot sia in esecuzione.');
        console.error('Chat error:', err);
    } finally {
        state.isChatting = false;
        els.chatSendBtn.disabled = false;
        els.chatInput.focus();
    }
}

function appendMessage(role, content, searchData = null) {
    const div = document.createElement('div');
    div.className = `message ${role}`;

    const avatar = role === 'user' ? '👤' : '🤖';
    const renderedContent = role === 'assistant' ? renderMarkdown(content) : escapeHtml(content);

    let searchHtml = '';
    if (searchData && searchData.results && searchData.results.length > 0) {
        searchHtml = `
            <div class="message-search-results">
                <div class="message-search-header">🔍 Risultati Google per "${escapeHtml(searchData.query)}"</div>
                ${searchData.results.slice(0, 5).map(r => `
                    <a href="${escapeHtml(r.url)}" target="_blank" rel="noopener" class="search-result-mini">
                        <div class="search-result-mini-title">${escapeHtml(r.title)}</div>
                        <div class="search-result-mini-url">${escapeHtml(extractDomain(r.url))}</div>
                    </a>
                `).join('')}
            </div>
        `;
    }

    div.innerHTML = `
        <div class="message-avatar">${avatar}</div>
        <div class="message-content">
            ${renderedContent}
            ${searchHtml}
        </div>
    `;

    els.chatMessages.appendChild(div);
    scrollToBottom();
}

function showTyping(text = 'SearchBot sta pensando...') {
    els.typingText.textContent = text;
    els.typingIndicator.style.display = 'flex';
    scrollToBottom();

    // Animate typing text
    const texts = [
        'SearchBot sta pensando...',
        'Analizzo la domanda...',
        'Cerco informazioni...',
        'Elaboro la risposta...',
    ];
    let idx = 0;
    state._typingInterval = setInterval(() => {
        idx = (idx + 1) % texts.length;
        els.typingText.textContent = texts[idx];
    }, 2500);
}

function hideTyping() {
    els.typingIndicator.style.display = 'none';
    if (state._typingInterval) {
        clearInterval(state._typingInterval);
        state._typingInterval = null;
    }
}

function scrollToBottom() {
    requestAnimationFrame(() => {
        els.chatMessages.scrollTop = els.chatMessages.scrollHeight;
    });
}

// ─── Conversations Sidebar ───────────────────────────────────────
async function loadConversations() {
    try {
        const response = await fetch('/api/conversations?limit=30');
        const data = await response.json();

        if (data.success && data.conversations.length > 0) {
            renderConversations(data.conversations);
        } else {
            els.conversationsList.innerHTML = `
                <div class="empty-conversations">
                    <p>Nessuna conversazione</p>
                </div>
            `;
        }
    } catch (err) {
        console.error('Conversations load error:', err);
    }
}

function renderConversations(conversations) {
    els.conversationsList.innerHTML = '';

    conversations.forEach(conv => {
        const div = document.createElement('div');
        div.className = `conv-item${conv.id === state.currentConversationId ? ' active' : ''}`;

        div.innerHTML = `
            <span class="conv-item-title">${escapeHtml(conv.title)}</span>
            <button class="conv-item-delete" data-id="${conv.id}" title="Elimina">✕</button>
        `;

        div.addEventListener('click', (e) => {
            if (e.target.closest('.conv-item-delete')) return;
            loadConversation(conv.id);
        });

        const deleteBtn = div.querySelector('.conv-item-delete');
        deleteBtn.addEventListener('click', async (e) => {
            e.stopPropagation();
            await deleteConversation(conv.id);
        });

        els.conversationsList.appendChild(div);
    });
}

async function loadConversation(convId) {
    try {
        const response = await fetch(`/api/conversations/${convId}`);
        const data = await response.json();

        if (data.success) {
            state.currentConversationId = convId;
            els.chatMessages.innerHTML = '';
            els.chatWelcome.style.display = 'none';
            els.chatMessages.style.display = 'flex';

            data.conversation.messages.forEach(msg => {
                let searchData = null;
                if (msg.search_results) {
                    try {
                        searchData = { results: JSON.parse(msg.search_results), query: '' };
                    } catch {}
                }
                appendMessage(msg.role, msg.content, searchData);
            });

            // Update sidebar active state
            $$('.conv-item').forEach(c => c.classList.remove('active'));
            const activeItem = $(`.conv-item-delete[data-id="${convId}"]`);
            if (activeItem) activeItem.closest('.conv-item').classList.add('active');
        }
    } catch (err) {
        showToast('Errore nel caricamento della conversazione', 'error');
    }
}

async function deleteConversation(convId) {
    try {
        const response = await fetch(`/api/conversations/${convId}`, { method: 'DELETE' });
        const data = await response.json();
        if (data.success) {
            if (state.currentConversationId === convId) {
                startNewChat();
            }
            loadConversations();
            showToast('Conversazione eliminata', 'info');
        }
    } catch (err) {
        showToast('Errore durante l\'eliminazione', 'error');
    }
}

// ─── Markdown Renderer ───────────────────────────────────────────
function renderMarkdown(text) {
    if (!text) return '';

    let html = escapeHtml(text);

    // Code blocks (```...```)
    html = html.replace(/```(\w*)\n?([\s\S]*?)```/g, (_, lang, code) => {
        return `<pre><code>${code.trim()}</code></pre>`;
    });

    // Inline code (`...`)
    html = html.replace(/`([^`]+)`/g, '<code>$1</code>');

    // Bold (**...**)
    html = html.replace(/\*\*([^*]+)\*\*/g, '<strong>$1</strong>');

    // Italic (*...*)
    html = html.replace(/(?<!\*)\*([^*]+)\*(?!\*)/g, '<em>$1</em>');

    // Headers
    html = html.replace(/^### (.+)$/gm, '<h3>$1</h3>');
    html = html.replace(/^## (.+)$/gm, '<h2>$1</h2>');
    html = html.replace(/^# (.+)$/gm, '<h1>$1</h1>');

    // Links [text](url)
    html = html.replace(/\[([^\]]+)\]\(([^)]+)\)/g, '<a href="$2" target="_blank" rel="noopener">$1</a>');

    // Unordered lists
    html = html.replace(/^[\-\*] (.+)$/gm, '<li>$1</li>');
    html = html.replace(/(<li>.*<\/li>\n?)+/g, '<ul>$&</ul>');

    // Ordered lists
    html = html.replace(/^\d+\. (.+)$/gm, '<li>$1</li>');

    // Blockquotes
    html = html.replace(/^&gt; (.+)$/gm, '<blockquote>$1</blockquote>');

    // Paragraphs (double newline)
    html = html.replace(/\n\n/g, '</p><p>');
    html = '<p>' + html + '</p>';

    // Clean up empty paragraphs
    html = html.replace(/<p>\s*<\/p>/g, '');
    html = html.replace(/<p>\s*(<h[1-3]>)/g, '$1');
    html = html.replace(/(<\/h[1-3]>)\s*<\/p>/g, '$1');
    html = html.replace(/<p>\s*(<pre>)/g, '$1');
    html = html.replace(/(<\/pre>)\s*<\/p>/g, '$1');
    html = html.replace(/<p>\s*(<ul>)/g, '$1');
    html = html.replace(/(<\/ul>)\s*<\/p>/g, '$1');
    html = html.replace(/<p>\s*(<blockquote>)/g, '$1');
    html = html.replace(/(<\/blockquote>)\s*<\/p>/g, '$1');

    // Single newlines to <br>
    html = html.replace(/\n/g, '<br>');

    return html;
}

// ═══════════════════════════════════════════════════════════════
// SEARCH (original functionality)
// ═══════════════════════════════════════════════════════════════

function initSearch() {
    els.searchBtn.addEventListener('click', performSearch);
    els.searchInput.addEventListener('keydown', (e) => {
        if (e.key === 'Enter') performSearch();
    });
    els.retryBtn.addEventListener('click', performSearch);

    // AI Analysis
    els.analyzeBtn.addEventListener('click', analyzeResults);
    els.aiAnalysisClose.addEventListener('click', () => {
        els.aiAnalysisArea.style.display = 'none';
    });
}

async function performSearch() {
    const query = els.searchInput.value.trim();
    if (!query || query.length < 2) {
        showToast('Inserisci almeno 2 caratteri', 'error');
        els.searchInput.focus();
        return;
    }

    if (state.isSearching) return;
    state.isSearching = true;
    state.lastQuery = query;

    // UI: Show loading
    els.searchBtn.disabled = true;
    els.resultsArea.style.display = 'none';
    els.errorContainer.style.display = 'none';
    els.loadingContainer.style.display = 'block';
    els.aiAnalysisArea.style.display = 'none';

    const loadingTexts = [
        'Sto cercando su Google...',
        'Analizzando i risultati...',
        'Filtrando i contenuti migliori...',
    ];
    let textIndex = 0;
    const loadingInterval = setInterval(() => {
        textIndex = (textIndex + 1) % loadingTexts.length;
        els.loadingSubtext.textContent = loadingTexts[textIndex];
    }, 2000);

    try {
        const response = await fetch('/api/search', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
                query: query,
                num_results: parseInt(els.numResults.value),
                lang: els.searchLang.value,
            }),
        });

        const data = await response.json();

        clearInterval(loadingInterval);
        els.loadingContainer.style.display = 'none';

        if (data.success && data.results.length > 0) {
            renderResults(data);
        } else if (data.success && data.results.length === 0) {
            showError('Nessun risultato trovato per questa query. Prova con parole diverse.');
        } else {
            showError(data.error || 'Errore durante la ricerca.');
        }
    } catch (err) {
        clearInterval(loadingInterval);
        els.loadingContainer.style.display = 'none';
        showError('Errore di connessione al server. Verifica che il bot sia in esecuzione.');
        console.error('Search error:', err);
    } finally {
        state.isSearching = false;
        els.searchBtn.disabled = false;
    }
}

// ─── Render Results ──────────────────────────────────────────────
function renderResults(data) {
    els.resultsTitle.textContent = `Risultati per "${data.query}"`;
    els.resultsMeta.textContent = `${data.results_count} risultati · ${data.method}`;

    els.resultsGrid.innerHTML = '';

    data.results.forEach((result, index) => {
        const card = document.createElement('div');
        card.className = 'result-card';
        card.style.animationDelay = `${index * 0.06}s`;

        const domain = extractDomain(result.url);

        card.innerHTML = `
            <span class="result-position">#${result.position}</span>
            <h3 class="result-title">${escapeHtml(result.title)}</h3>
            <a href="${escapeHtml(result.url)}" target="_blank" rel="noopener noreferrer" class="result-url">
                <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                    <path d="M18 13v6a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V8a2 2 0 0 1 2-2h6"></path>
                    <polyline points="15 3 21 3 21 9"></polyline>
                    <line x1="10" y1="14" x2="21" y2="3"></line>
                </svg>
                ${escapeHtml(domain)}
            </a>
            <p class="result-description">${escapeHtml(result.description)}</p>
        `;

        els.resultsGrid.appendChild(card);
    });

    els.resultsArea.style.display = 'block';

    // Scroll to results
    setTimeout(() => {
        els.resultsArea.scrollIntoView({ behavior: 'smooth', block: 'start' });
    }, 100);

    // Store results for export
    state.lastResults = data;
    showToast(`${data.results_count} risultati trovati!`, 'success');
}

// ─── AI Analysis ─────────────────────────────────────────────────
async function analyzeResults() {
    if (!state.lastResults || !state.lastResults.search_id) {
        showToast('Nessun risultato da analizzare', 'error');
        return;
    }

    if (!state.aiAvailable) {
        showToast('AI non disponibile. Verifica la GROQ_API_KEY.', 'error');
        return;
    }

    els.aiAnalysisContent.innerHTML = '<p style="color: var(--text-muted);">🤖 Analisi in corso...</p>';
    els.aiAnalysisArea.style.display = 'block';

    try {
        const response = await fetch('/api/analyze', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
                search_id: state.lastResults.search_id,
                question: state.lastResults.query,
            }),
        });

        const data = await response.json();

        if (data.success) {
            els.aiAnalysisContent.innerHTML = renderMarkdown(data.analysis);
        } else {
            els.aiAnalysisContent.innerHTML = `<p style="color: var(--accent-red);">❌ ${escapeHtml(data.error)}</p>`;
        }
    } catch (err) {
        els.aiAnalysisContent.innerHTML = '<p style="color: var(--accent-red);">❌ Errore di connessione</p>';
    }
}

// ─── Error Display ───────────────────────────────────────────────
function showError(message) {
    els.errorText.textContent = message;
    els.errorContainer.style.display = 'block';
}

// ─── History ─────────────────────────────────────────────────────
function initHistory() {
    els.clearHistoryBtn.addEventListener('click', clearHistory);
}

async function loadHistory() {
    try {
        const response = await fetch('/api/history?limit=50');
        const data = await response.json();

        if (data.success && data.history.length > 0) {
            renderHistory(data.history);
        } else {
            els.historyList.innerHTML = `
                <div class="empty-state">
                    <div class="empty-icon">📭</div>
                    <p class="empty-text">Nessuna ricerca nello storico</p>
                    <p class="empty-subtext">Le tue ricerche appariranno qui</p>
                </div>
            `;
        }
    } catch (err) {
        console.error('History load error:', err);
        showToast('Errore nel caricamento dello storico', 'error');
    }
}

function renderHistory(history) {
    els.historyList.innerHTML = '';

    history.forEach((item, index) => {
        const el = document.createElement('div');
        el.className = 'history-item';
        el.style.animationDelay = `${index * 0.04}s`;

        const date = new Date(item.created_at).toLocaleString('it-IT', {
            day: '2-digit',
            month: 'short',
            year: 'numeric',
            hour: '2-digit',
            minute: '2-digit',
        });

        let previewHtml = '';
        if (item.results && item.results.length > 0) {
            previewHtml = item.results.slice(0, 5).map(r => `
                <div class="preview-result">
                    <div class="preview-result-title">${escapeHtml(r.title)}</div>
                    <a href="${escapeHtml(r.url)}" target="_blank" rel="noopener" class="preview-result-url">${escapeHtml(extractDomain(r.url))}</a>
                </div>
            `).join('');
        }

        el.innerHTML = `
            <div class="history-item-header">
                <span class="history-query">${escapeHtml(item.query)}</span>
                <div class="history-actions">
                    <button class="history-delete-btn" data-id="${item.id}" title="Elimina">
                        <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                            <line x1="18" y1="6" x2="6" y2="18"></line>
                            <line x1="6" y1="6" x2="18" y2="18"></line>
                        </svg>
                    </button>
                </div>
            </div>
            <div class="history-meta">
                <span>📅 ${date}</span>
                <span>📊 ${item.results_count} risultati</span>
            </div>
            <div class="history-results-preview">${previewHtml}</div>
        `;

        // Toggle expand
        el.addEventListener('click', (e) => {
            if (e.target.closest('.history-delete-btn') || e.target.closest('.preview-result-url')) return;
            el.classList.toggle('expanded');
        });

        // Delete handler
        const deleteBtn = el.querySelector('.history-delete-btn');
        deleteBtn.addEventListener('click', (e) => {
            e.stopPropagation();
            deleteHistoryItem(item.id);
        });

        els.historyList.appendChild(el);
    });
}

async function deleteHistoryItem(id) {
    try {
        const response = await fetch(`/api/history/${id}`, { method: 'DELETE' });
        const data = await response.json();
        if (data.success) {
            showToast('Ricerca eliminata', 'info');
            loadHistory();
        }
    } catch (err) {
        showToast('Errore durante l\'eliminazione', 'error');
    }
}

async function clearHistory() {
    if (!confirm('Sei sicuro di voler eliminare tutto lo storico?')) return;

    try {
        const response = await fetch('/api/history/clear', { method: 'DELETE' });
        const data = await response.json();
        if (data.success) {
            showToast('Storico eliminato', 'success');
            loadHistory();
        }
    } catch (err) {
        showToast('Errore durante l\'eliminazione', 'error');
    }
}

// ─── Statistics ──────────────────────────────────────────────────
async function loadStats() {
    try {
        const response = await fetch('/api/stats');
        const data = await response.json();

        if (data.success) {
            const stats = data.stats;
            animateNumber(els.statSearches, stats.total_searches);
            animateNumber(els.statResults, stats.total_results);
            animateNumber(els.statConversations, stats.total_conversations || 0);

            const avg = stats.total_searches > 0
                ? Math.round(stats.total_results / stats.total_searches)
                : 0;
            animateNumber(els.statAvg, avg);

            renderTopQueries(stats.top_queries);
        }
    } catch (err) {
        console.error('Stats load error:', err);
    }
}

function animateNumber(element, target) {
    if (!element) return;
    const duration = 800;
    const start = parseInt(element.textContent) || 0;
    const diff = target - start;
    const startTime = performance.now();

    function update(currentTime) {
        const elapsed = currentTime - startTime;
        const progress = Math.min(elapsed / duration, 1);
        const eased = 1 - Math.pow(1 - progress, 3); // easeOutCubic
        element.textContent = Math.round(start + diff * eased);

        if (progress < 1) {
            requestAnimationFrame(update);
        }
    }

    requestAnimationFrame(update);
}

function renderTopQueries(queries) {
    if (!queries || queries.length === 0) {
        els.topQueriesList.innerHTML = `
            <div class="empty-state small">
                <p class="empty-text">Nessun dato disponibile</p>
            </div>
        `;
        return;
    }

    els.topQueriesList.innerHTML = queries.map((q, i) => `
        <div class="top-query-item">
            <span class="top-query-rank">#${i + 1}</span>
            <span class="top-query-text">${escapeHtml(q.query)}</span>
            <span class="top-query-count">${q.count}×</span>
        </div>
    `).join('');
}

// ─── Export & Copy ───────────────────────────────────────────────
function initExport() {
    els.exportBtn.addEventListener('click', exportResults);
    els.copyBtn.addEventListener('click', copyResults);
}

function exportResults() {
    if (!state.lastResults) return;

    const data = state.lastResults;
    let text = `SearchBot AI — Risultati per "${data.query}"\n`;
    text += `Data: ${new Date().toLocaleString('it-IT')}\n`;
    text += `Risultati: ${data.results_count}\n`;
    text += `${'═'.repeat(60)}\n\n`;

    data.results.forEach(r => {
        text += `#${r.position} — ${r.title}\n`;
        text += `URL: ${r.url}\n`;
        text += `${r.description}\n\n`;
    });

    const blob = new Blob([text], { type: 'text/plain;charset=utf-8' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `searchbot_${data.query.replace(/\s+/g, '_').substring(0, 30)}.txt`;
    a.click();
    URL.revokeObjectURL(url);

    showToast('Risultati esportati!', 'success');
}

function copyResults() {
    if (!state.lastResults) return;

    const data = state.lastResults;
    let text = data.results.map(r =>
        `${r.title}\n${r.url}\n${r.description}`
    ).join('\n\n');

    navigator.clipboard.writeText(text).then(() => {
        showToast('Risultati copiati negli appunti!', 'success');
    }).catch(() => {
        showToast('Impossibile copiare', 'error');
    });
}

// ─── Health Check ────────────────────────────────────────────────
async function checkHealth() {
    try {
        const response = await fetch('/api/health');
        const data = await response.json();
        if (data.status === 'ok') {
            $('#statusDot').style.background = 'var(--accent-green)';
            $('#statusText').textContent = 'Online';

            // Check AI status
            state.aiAvailable = data.ai_available || false;
            if (state.aiAvailable) {
                els.aiStatus.title = 'AI disponibile';
                els.aiStatus.classList.remove('unavailable');
            } else {
                els.aiStatus.title = 'AI non disponibile — GROQ_API_KEY mancante';
                els.aiStatus.classList.add('unavailable');
            }
        }
    } catch {
        $('#statusDot').style.background = 'var(--accent-red)';
        $('#statusText').textContent = 'Offline';
        els.aiStatus.classList.add('unavailable');
    }
}

// ─── Toast Notifications ─────────────────────────────────────────
function showToast(message, type = 'info') {
    const toast = document.createElement('div');
    toast.className = `toast ${type}`;

    const icons = {
        success: '✅',
        error: '❌',
        info: 'ℹ️',
    };

    toast.innerHTML = `<span>${icons[type] || 'ℹ️'}</span> ${escapeHtml(message)}`;
    els.toastContainer.appendChild(toast);

    setTimeout(() => {
        toast.style.animation = 'toastSlideOut 0.3s ease-in forwards';
        setTimeout(() => toast.remove(), 300);
    }, 3500);
}

// ─── Utilities ───────────────────────────────────────────────────
function escapeHtml(text) {
    if (!text) return '';
    const div = document.createElement('div');
    div.textContent = text;
    return div.innerHTML;
}

function extractDomain(url) {
    try {
        const parsed = new URL(url);
        return parsed.hostname.replace('www.', '');
    } catch {
        return url;
    }
}
