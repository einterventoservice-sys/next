"""
SearchBot — Modulo Database SQLite
Gestisce lo storico delle ricerche, conversazioni AI e messaggi.
"""

import sqlite3
import os
import json
from datetime import datetime

DB_PATH = os.path.join(os.path.dirname(os.path.abspath(__file__)), "searchbot.db")


def get_connection():
    """Crea e restituisce una connessione al database."""
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA journal_mode=WAL")
    conn.execute("PRAGMA foreign_keys=ON")
    return conn


def init_db():
    """Inizializza le tabelle del database se non esistono."""
    conn = get_connection()
    cursor = conn.cursor()

    cursor.execute("""
        CREATE TABLE IF NOT EXISTS searches (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            query TEXT NOT NULL,
            results_count INTEGER DEFAULT 0,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        )
    """)

    cursor.execute("""
        CREATE TABLE IF NOT EXISTS results (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            search_id INTEGER NOT NULL,
            title TEXT,
            url TEXT,
            description TEXT,
            position INTEGER,
            FOREIGN KEY (search_id) REFERENCES searches(id) ON DELETE CASCADE
        )
    """)

    cursor.execute("""
        CREATE INDEX IF NOT EXISTS idx_results_search_id ON results(search_id)
    """)

    # ─── Tabelle AI ──────────────────────────────────────────────
    cursor.execute("""
        CREATE TABLE IF NOT EXISTS conversations (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            title TEXT DEFAULT 'Nuova conversazione',
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        )
    """)

    cursor.execute("""
        CREATE TABLE IF NOT EXISTS messages (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            conversation_id INTEGER NOT NULL,
            role TEXT NOT NULL CHECK(role IN ('user', 'assistant', 'system')),
            content TEXT NOT NULL,
            search_id INTEGER,
            search_results TEXT,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY (conversation_id) REFERENCES conversations(id) ON DELETE CASCADE,
            FOREIGN KEY (search_id) REFERENCES searches(id) ON DELETE SET NULL
        )
    """)

    cursor.execute("""
        CREATE INDEX IF NOT EXISTS idx_messages_conversation_id ON messages(conversation_id)
    """)

    conn.commit()
    conn.close()


# ─── Ricerche (originali) ────────────────────────────────────────

def save_search(query, results):
    """
    Salva una ricerca e i suoi risultati nel database.
    
    Args:
        query: La query di ricerca
        results: Lista di dict con {title, url, description, position}
    
    Returns:
        ID della ricerca salvata
    """
    conn = get_connection()
    cursor = conn.cursor()

    cursor.execute(
        "INSERT INTO searches (query, results_count) VALUES (?, ?)",
        (query, len(results))
    )
    search_id = cursor.lastrowid

    for result in results:
        cursor.execute(
            "INSERT INTO results (search_id, title, url, description, position) VALUES (?, ?, ?, ?, ?)",
            (search_id, result.get("title", ""), result.get("url", ""), 
             result.get("description", ""), result.get("position", 0))
        )

    conn.commit()
    conn.close()
    return search_id


def get_history(limit=50, offset=0):
    """
    Recupera lo storico delle ricerche.
    
    Args:
        limit: Numero massimo di ricerche da restituire
        offset: Offset per paginazione
    
    Returns:
        Lista di ricerche con risultati
    """
    conn = get_connection()
    cursor = conn.cursor()

    cursor.execute(
        "SELECT * FROM searches ORDER BY created_at DESC LIMIT ? OFFSET ?",
        (limit, offset)
    )
    searches = [dict(row) for row in cursor.fetchall()]

    for search in searches:
        cursor.execute(
            "SELECT * FROM results WHERE search_id = ? ORDER BY position",
            (search["id"],)
        )
        search["results"] = [dict(row) for row in cursor.fetchall()]

    conn.close()
    return searches


def get_search_by_id(search_id):
    """Recupera una ricerca specifica per ID."""
    conn = get_connection()
    cursor = conn.cursor()

    cursor.execute("SELECT * FROM searches WHERE id = ?", (search_id,))
    search = cursor.fetchone()

    if search is None:
        conn.close()
        return None

    search = dict(search)
    cursor.execute(
        "SELECT * FROM results WHERE search_id = ? ORDER BY position",
        (search_id,)
    )
    search["results"] = [dict(row) for row in cursor.fetchall()]

    conn.close()
    return search


def delete_search(search_id):
    """Elimina una ricerca e i suoi risultati."""
    conn = get_connection()
    cursor = conn.cursor()
    cursor.execute("DELETE FROM searches WHERE id = ?", (search_id,))
    affected = cursor.rowcount
    conn.commit()
    conn.close()
    return affected > 0


def clear_history():
    """Elimina tutto lo storico."""
    conn = get_connection()
    cursor = conn.cursor()
    cursor.execute("DELETE FROM results")
    cursor.execute("DELETE FROM searches")
    conn.commit()
    conn.close()


def get_stats():
    """Restituisce statistiche generali."""
    conn = get_connection()
    cursor = conn.cursor()

    cursor.execute("SELECT COUNT(*) as total_searches FROM searches")
    total_searches = cursor.fetchone()["total_searches"]

    cursor.execute("SELECT COUNT(*) as total_results FROM results")
    total_results = cursor.fetchone()["total_results"]

    cursor.execute("""
        SELECT query, COUNT(*) as count 
        FROM searches 
        GROUP BY query 
        ORDER BY count DESC 
        LIMIT 5
    """)
    top_queries = [dict(row) for row in cursor.fetchall()]

    cursor.execute("SELECT COUNT(*) as total FROM conversations")
    total_conversations = cursor.fetchone()["total"]

    cursor.execute("SELECT COUNT(*) as total FROM messages")
    total_messages = cursor.fetchone()["total"]

    conn.close()
    return {
        "total_searches": total_searches,
        "total_results": total_results,
        "top_queries": top_queries,
        "total_conversations": total_conversations,
        "total_messages": total_messages,
    }


# ─── Conversazioni AI ───────────────────────────────────────────

def create_conversation(title=None):
    """
    Crea una nuova conversazione.
    
    Args:
        title: Titolo opzionale
        
    Returns:
        ID della conversazione creata
    """
    conn = get_connection()
    cursor = conn.cursor()
    cursor.execute(
        "INSERT INTO conversations (title) VALUES (?)",
        (title or "Nuova conversazione",)
    )
    conv_id = cursor.lastrowid
    conn.commit()
    conn.close()
    return conv_id


def update_conversation_title(conversation_id, title):
    """Aggiorna il titolo di una conversazione."""
    conn = get_connection()
    cursor = conn.cursor()
    cursor.execute(
        "UPDATE conversations SET title = ?, updated_at = CURRENT_TIMESTAMP WHERE id = ?",
        (title, conversation_id)
    )
    conn.commit()
    conn.close()


def get_conversations(limit=50):
    """Recupera la lista delle conversazioni recenti."""
    conn = get_connection()
    cursor = conn.cursor()
    cursor.execute(
        "SELECT * FROM conversations ORDER BY updated_at DESC LIMIT ?",
        (limit,)
    )
    conversations = [dict(row) for row in cursor.fetchall()]

    for conv in conversations:
        cursor.execute(
            "SELECT COUNT(*) as msg_count FROM messages WHERE conversation_id = ?",
            (conv["id"],)
        )
        conv["message_count"] = cursor.fetchone()["msg_count"]

    conn.close()
    return conversations


def get_conversation(conversation_id):
    """Recupera una conversazione con tutti i suoi messaggi."""
    conn = get_connection()
    cursor = conn.cursor()

    cursor.execute("SELECT * FROM conversations WHERE id = ?", (conversation_id,))
    conv = cursor.fetchone()
    if conv is None:
        conn.close()
        return None

    conv = dict(conv)
    cursor.execute(
        "SELECT * FROM messages WHERE conversation_id = ? ORDER BY created_at ASC",
        (conversation_id,)
    )
    conv["messages"] = [dict(row) for row in cursor.fetchall()]

    conn.close()
    return conv


def delete_conversation(conversation_id):
    """Elimina una conversazione e tutti i suoi messaggi."""
    conn = get_connection()
    cursor = conn.cursor()
    cursor.execute("DELETE FROM conversations WHERE id = ?", (conversation_id,))
    affected = cursor.rowcount
    conn.commit()
    conn.close()
    return affected > 0


def save_message(conversation_id, role, content, search_id=None, search_results=None):
    """
    Salva un messaggio in una conversazione.
    
    Args:
        conversation_id: ID conversazione
        role: 'user' o 'assistant'
        content: Contenuto del messaggio
        search_id: ID ricerca associata (opzionale)
        search_results: JSON dei risultati di ricerca (opzionale)
        
    Returns:
        ID del messaggio salvato
    """
    conn = get_connection()
    cursor = conn.cursor()

    results_json = json.dumps(search_results, ensure_ascii=False) if search_results else None

    cursor.execute(
        """INSERT INTO messages (conversation_id, role, content, search_id, search_results) 
           VALUES (?, ?, ?, ?, ?)""",
        (conversation_id, role, content, search_id, results_json)
    )
    msg_id = cursor.lastrowid

    # Aggiorna timestamp conversazione
    cursor.execute(
        "UPDATE conversations SET updated_at = CURRENT_TIMESTAMP WHERE id = ?",
        (conversation_id,)
    )

    conn.commit()
    conn.close()
    return msg_id


def get_conversation_messages(conversation_id, limit=50):
    """Recupera i messaggi di una conversazione."""
    conn = get_connection()
    cursor = conn.cursor()
    cursor.execute(
        """SELECT * FROM messages 
           WHERE conversation_id = ? 
           ORDER BY created_at ASC 
           LIMIT ?""",
        (conversation_id, limit)
    )
    messages = [dict(row) for row in cursor.fetchall()]
    conn.close()
    return messages
