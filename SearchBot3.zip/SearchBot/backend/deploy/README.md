# 🤖 SearchBot AI — Guida Deploy su Debian Linux VDS

## Prerequisiti

- VDS con **Debian 11/12** (Bullseye/Bookworm)
- Accesso **root** o utente con `sudo`
- Almeno **512 MB RAM** e **1 GB disco**
- **API Key Groq** (gratuita) per funzionalità AI → [console.groq.com](https://console.groq.com)

---

## 🚀 Setup Automatico (Consigliato)

Il modo più semplice è usare lo script di setup automatico:

```bash
# 1. Carica i file sul VDS (da locale)
scp -r SearchBot/ root@TUO_IP_VDS:/tmp/

# 2. Connettiti al VDS
ssh root@TUO_IP_VDS

# 3. Esegui lo script di setup
cd /tmp/SearchBot/backend/deploy/
chmod +x setup.sh
bash setup.sh
```

Lo script farà tutto automaticamente:
- ✅ Chiede la GROQ_API_KEY per l'IA (opzionale)
- ✅ Installa Python 3, pip, dipendenze di sistema
- ✅ Crea un utente di servizio dedicato
- ✅ Copia i file in `/opt/searchbot/`
- ✅ Crea l'ambiente virtuale Python con Groq SDK
- ✅ Configura il servizio systemd
- ✅ Apre la porta nel firewall (UFW)
- ✅ Avvia il bot

---

## 🔑 Configurazione API Key Groq

L'AI è alimentata da **Groq** (gratuito). Per attivarla:

1. Vai su [console.groq.com](https://console.groq.com)
2. Crea un account (gratuito)
3. Genera una API Key
4. Inseriscila durante il setup, oppure dopo:

```bash
# Modifica il file .env
nano /opt/searchbot/.env

# Aggiungi/modifica:
GROQ_API_KEY=gsk_la_tua_api_key_qui

# Riavvia il servizio
sudo systemctl restart searchbot
```

### Limiti Piano Gratuito Groq
- ~30 richieste/minuto
- ~6000 tokens/minuto (Llama 3.3 70B)
- Per uso più intensivo: [groq.com/pricing](https://groq.com/pricing)

---

## 🔧 Setup Manuale

Se preferisci installare manualmente:

### 1. Installa dipendenze

```bash
sudo apt update
sudo apt install -y python3 python3-pip python3-venv python3-dev \
    libxml2-dev libxslt1-dev zlib1g-dev
```

### 2. Copia i file

```bash
sudo mkdir -p /opt/searchbot
sudo cp -r backend/* /opt/searchbot/
```

### 3. Crea ambiente virtuale

```bash
cd /opt/searchbot
sudo python3 -m venv venv
sudo ./venv/bin/pip install -r requirements.txt
```

### 4. Configura API Key

```bash
sudo tee /opt/searchbot/.env << EOF
GROQ_API_KEY=la_tua_api_key
EOF
```

### 5. Test rapido

```bash
cd /opt/searchbot
export GROQ_API_KEY=la_tua_api_key
sudo ./venv/bin/python app.py
# Apri http://TUO_IP:5000 nel browser
```

### 6. Configura systemd

```bash
sudo cp deploy/searchbot.service /etc/systemd/system/
sudo mkdir -p /var/log/searchbot
sudo useradd --system --no-create-home searchbot
sudo chown -R searchbot:searchbot /opt/searchbot /var/log/searchbot
sudo systemctl daemon-reload
sudo systemctl enable searchbot
sudo systemctl start searchbot
```

### 7. Configura firewall

```bash
sudo ufw allow 5000/tcp
sudo ufw enable
```

---

## 📋 Comandi Utili

| Comando | Descrizione |
|---|---|
| `sudo systemctl status searchbot` | Stato del servizio |
| `sudo systemctl restart searchbot` | Riavvia il bot |
| `sudo systemctl stop searchbot` | Ferma il bot |
| `sudo systemctl start searchbot` | Avvia il bot |
| `sudo journalctl -u searchbot -f` | Log in tempo reale |
| `sudo journalctl -u searchbot --since today` | Log di oggi |
| `nano /opt/searchbot/.env` | Modifica API key |

---

## 🌐 Accesso Dashboard

Dopo l'installazione, apri nel browser:

```
http://TUO_IP_VDS:5000
```

### Funzionalità:
- **🤖 Chat AI** — Chatta con l'assistente AI, fa ricerche automatiche su Google
- **🔍 Ricerca** — Ricerca diretta su Google con risultati
- **📜 Storico** — Tutte le ricerche salvate
- **📊 Statistiche** — Dati sull'utilizzo

---

## 🔒 SSL con Nginx (Opzionale)

Per abilitare HTTPS con un dominio:

```bash
# Installa Nginx e Certbot
sudo apt install -y nginx certbot python3-certbot-nginx

# Configura Nginx come reverse proxy
sudo tee /etc/nginx/sites-available/searchbot << 'EOF'
server {
    listen 80;
    server_name tuodominio.com;

    location / {
        proxy_pass http://127.0.0.1:5000;
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto $scheme;
        proxy_read_timeout 120s;
    }
}
EOF

# Attiva il sito
sudo ln -s /etc/nginx/sites-available/searchbot /etc/nginx/sites-enabled/
sudo nginx -t
sudo systemctl restart nginx

# Ottieni certificato SSL
sudo certbot --nginx -d tuodominio.com
```

---

## 📡 API Endpoints

### Chat AI
| Metodo | Endpoint | Descrizione |
|---|---|---|
| POST | `/api/chat` | Invia messaggio alla chat AI |
| POST | `/api/analyze` | Analizza risultati con AI |
| GET | `/api/ai/status` | Stato del motore AI |
| GET | `/api/conversations` | Lista conversazioni |
| GET | `/api/conversations/<id>` | Dettaglio conversazione |
| DELETE | `/api/conversations/<id>` | Elimina conversazione |

### Ricerca
| Metodo | Endpoint | Descrizione |
|---|---|---|
| POST | `/api/search` | Esegui ricerca Google |
| GET | `/api/history` | Storico ricerche |
| DELETE | `/api/history/<id>` | Elimina ricerca |
| DELETE | `/api/history/clear` | Elimina tutto |
| GET | `/api/stats` | Statistiche |
| GET | `/api/health` | Health check |

---

## ⚠️ Note Importanti

- **Google Rate Limiting**: Il bot include rotazione User-Agent e delay randomici, ma per uso intensivo (>100 ricerche/giorno) è consigliabile integrare un proxy o usare la Google Custom Search API.
- **Backup Database**: Il database SQLite si trova in `/opt/searchbot/searchbot.db`. Puoi fare backup con: `cp /opt/searchbot/searchbot.db /backup/`
- **Aggiornamento**: Per aggiornare, carica i nuovi file e riavvia: `sudo systemctl restart searchbot`
- **AI senza API Key**: Se non configuri la GROQ_API_KEY, il bot funziona comunque per le ricerche Google, ma la chat AI sarà disabilitata.
