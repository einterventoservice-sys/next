#!/bin/bash
# ═══════════════════════════════════════════════════════════════
# SearchBot AI — Script di Setup Automatico per Debian Linux
# Installa tutte le dipendenze, crea l'ambiente virtuale,
# configura systemd, API key e il firewall.
# ═══════════════════════════════════════════════════════════════

set -e

# Colori
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
PURPLE='\033[0;35m'
CYAN='\033[0;36m'
NC='\033[0m' # No Color

echo -e "${PURPLE}"
echo "╔═══════════════════════════════════════════╗"
echo "║     🤖 SearchBot AI — Setup Debian        ║"
echo "╚═══════════════════════════════════════════╝"
echo -e "${NC}"

# ─── Controlla se siamo root ──────────────────────────────────
if [ "$EUID" -ne 0 ]; then
    echo -e "${RED}❌ Esegui questo script come root: sudo bash setup.sh${NC}"
    exit 1
fi

# ─── Configurazione ──────────────────────────────────────────
INSTALL_DIR="/opt/searchbot"
SERVICE_USER="searchbot"
SERVICE_NAME="searchbot"
PORT=5000
ENV_FILE="$INSTALL_DIR/.env"

echo -e "${BLUE}📦 Configurazione:${NC}"
echo "   Directory: $INSTALL_DIR"
echo "   Utente:    $SERVICE_USER"
echo "   Porta:     $PORT"
echo ""

# ─── Chiedi API Key Groq ─────────────────────────────────────
echo -e "${CYAN}╔═══════════════════════════════════════════╗"
echo -e "║  🔑 Configurazione API Key Groq (IA)      ║"
echo -e "╚═══════════════════════════════════════════╝${NC}"
echo ""
echo -e "${YELLOW}Per usare le funzionalità AI, serve una API key gratuita di Groq.${NC}"
echo -e "Ottienila su: ${BLUE}https://console.groq.com${NC}"
echo ""

GROQ_API_KEY=""
read -p "Inserisci la tua GROQ_API_KEY (lascia vuoto per saltare): " GROQ_API_KEY

if [ -z "$GROQ_API_KEY" ]; then
    echo -e "${YELLOW}  ⚠️ API Key non inserita. L'AI sarà disabilitata.${NC}"
    echo -e "  Puoi aggiungerla dopo in: $ENV_FILE"
else
    echo -e "${GREEN}  ✅ API Key configurata${NC}"
fi
echo ""

# ─── 1. Aggiorna sistema e installa dipendenze ───────────────
echo -e "${YELLOW}[1/7] Aggiornamento sistema e installazione dipendenze...${NC}"
apt-get update -qq
apt-get install -y -qq python3 python3-pip python3-venv python3-dev \
    libxml2-dev libxslt1-dev zlib1g-dev \
    ufw curl > /dev/null 2>&1
echo -e "${GREEN}  ✅ Dipendenze sistema installate${NC}"

# ─── 2. Crea utente di servizio ──────────────────────────────
echo -e "${YELLOW}[2/7] Creazione utente di servizio...${NC}"
if id "$SERVICE_USER" &>/dev/null; then
    echo -e "${GREEN}  ✅ Utente $SERVICE_USER già esistente${NC}"
else
    useradd --system --no-create-home --shell /usr/sbin/nologin "$SERVICE_USER"
    echo -e "${GREEN}  ✅ Utente $SERVICE_USER creato${NC}"
fi

# ─── 3. Copia file del progetto ──────────────────────────────
echo -e "${YELLOW}[3/7] Installazione SearchBot AI...${NC}"
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
BACKEND_DIR="$(dirname "$SCRIPT_DIR")"

mkdir -p "$INSTALL_DIR"

# Copia file backend
cp "$BACKEND_DIR/app.py" "$INSTALL_DIR/"
cp "$BACKEND_DIR/scraper.py" "$INSTALL_DIR/"
cp "$BACKEND_DIR/database.py" "$INSTALL_DIR/"
cp "$BACKEND_DIR/ai_engine.py" "$INSTALL_DIR/"
cp "$BACKEND_DIR/requirements.txt" "$INSTALL_DIR/"
cp -r "$BACKEND_DIR/static" "$INSTALL_DIR/"

# Crea file .env
cat > "$ENV_FILE" << EOF
# SearchBot AI — Variabili d'ambiente
# Groq API Key per funzionalità AI
GROQ_API_KEY=$GROQ_API_KEY
EOF

chown -R "$SERVICE_USER:$SERVICE_USER" "$INSTALL_DIR"
echo -e "${GREEN}  ✅ File copiati in $INSTALL_DIR${NC}"

# ─── 4. Crea ambiente virtuale e installa pacchetti Python ───
echo -e "${YELLOW}[4/7] Creazione ambiente virtuale Python...${NC}"
python3 -m venv "$INSTALL_DIR/venv"
"$INSTALL_DIR/venv/bin/pip" install --upgrade pip -q
"$INSTALL_DIR/venv/bin/pip" install -r "$INSTALL_DIR/requirements.txt" -q
chown -R "$SERVICE_USER:$SERVICE_USER" "$INSTALL_DIR"
echo -e "${GREEN}  ✅ Ambiente virtuale creato e pacchetti installati${NC}"

# ─── 5. Configura systemd ────────────────────────────────────
echo -e "${YELLOW}[5/7] Configurazione servizio systemd...${NC}"
cat > /etc/systemd/system/${SERVICE_NAME}.service << EOF
[Unit]
Description=SearchBot AI — Assistente di Ricerca Intelligente con Dashboard Web
After=network.target
Wants=network-online.target

[Service]
Type=exec
User=$SERVICE_USER
Group=$SERVICE_USER
WorkingDirectory=$INSTALL_DIR
EnvironmentFile=$ENV_FILE
ExecStart=$INSTALL_DIR/venv/bin/gunicorn \
    --bind 0.0.0.0:$PORT \
    --workers 2 \
    --timeout 120 \
    --access-logfile /var/log/searchbot/access.log \
    --error-logfile /var/log/searchbot/error.log \
    app:app
Restart=always
RestartSec=5
StandardOutput=journal
StandardError=journal
SyslogIdentifier=$SERVICE_NAME

# Sicurezza
NoNewPrivileges=true
ProtectSystem=strict
ProtectHome=true
ReadWritePaths=$INSTALL_DIR /var/log/searchbot
PrivateTmp=true

[Install]
WantedBy=multi-user.target
EOF

# Crea directory log
mkdir -p /var/log/searchbot
chown -R "$SERVICE_USER:$SERVICE_USER" /var/log/searchbot

systemctl daemon-reload
echo -e "${GREEN}  ✅ Servizio systemd configurato${NC}"

# ─── 6. Configura firewall ───────────────────────────────────
echo -e "${YELLOW}[6/7] Configurazione firewall (UFW)...${NC}"
ufw allow $PORT/tcp > /dev/null 2>&1 || true
echo -e "${GREEN}  ✅ Porta $PORT aperta nel firewall${NC}"

# ─── 7. Avvia il servizio ────────────────────────────────────
echo -e "${YELLOW}[7/7] Avvio SearchBot AI...${NC}"
systemctl enable "$SERVICE_NAME" > /dev/null 2>&1
systemctl start "$SERVICE_NAME"

# Verifica che sia partito
sleep 2
if systemctl is-active --quiet "$SERVICE_NAME"; then
    echo -e "${GREEN}  ✅ SearchBot AI avviato con successo!${NC}"
else
    echo -e "${RED}  ❌ Errore nell'avvio. Controlla: journalctl -u $SERVICE_NAME -f${NC}"
    exit 1
fi

# ─── Riepilogo ────────────────────────────────────────────────
echo ""
echo -e "${PURPLE}╔═══════════════════════════════════════════╗"
echo -e "║         🎉 Setup Completato!              ║"
echo -e "╚═══════════════════════════════════════════╝${NC}"
echo ""
echo -e "${GREEN}SearchBot AI è in esecuzione!${NC}"
echo ""

# Ottieni IP del server
SERVER_IP=$(hostname -I | awk '{print $1}')
echo -e "  🌐 Dashboard:  ${BLUE}http://${SERVER_IP}:${PORT}${NC}"
echo -e "  📁 Directory:   $INSTALL_DIR"
echo -e "  📋 Log:         /var/log/searchbot/"
echo -e "  🔑 API Key:     $ENV_FILE"

if [ -z "$GROQ_API_KEY" ]; then
    echo ""
    echo -e "${YELLOW}⚠️  Per abilitare l'AI, aggiungi la GROQ_API_KEY:${NC}"
    echo -e "  1. Ottieni la key su: ${BLUE}https://console.groq.com${NC}"
    echo -e "  2. Modifica: ${CYAN}nano $ENV_FILE${NC}"
    echo -e "  3. Riavvia: ${CYAN}sudo systemctl restart searchbot${NC}"
fi

echo ""
echo -e "${YELLOW}Comandi utili:${NC}"
echo "  sudo systemctl status searchbot    — Stato del servizio"
echo "  sudo systemctl restart searchbot   — Riavvia"
echo "  sudo systemctl stop searchbot      — Ferma"
echo "  sudo journalctl -u searchbot -f    — Log in tempo reale"
echo "  nano $ENV_FILE                     — Modifica API key"
echo ""
