"""
SearchBot — Modulo Database SQLite
Gestisce lo storico delle ricerche e dei risultati.
"""

import sqlite3
import os
import json
from datetime import datetime

DB_PATH = os.path.join(os.path.dirname(os.path.abspath(__file__)), "searchbot.db")


def get_connection():
    """Crea e restituisce una connessione al database."""
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA journal_mode=WAL")
    conn.execute("PRAGMA foreign_keys=ON")
    return conn


def init_db():
    """Inizializza le tabelle del database se non esistono."""
    conn = get_connection()
    cursor = conn.cursor()

    cursor.execute("""
        CREATE TABLE IF NOT EXISTS searches (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            query TEXT NOT NULL,
            results_count INTEGER DEFAULT 0,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        )
    """)

    cursor.execute("""
        CREATE TABLE IF NOT EXISTS results (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            search_id INTEGER NOT NULL,
            title TEXT,
            url TEXT,
            description TEXT,
            position INTEGER,
            FOREIGN KEY (search_id) REFERENCES searches(id) ON DELETE CASCADE
        )
    """)

    cursor.execute("""
        CREATE INDEX IF NOT EXISTS idx_results_search_id ON results(search_id)
    """)

    conn.commit()
    conn.close()


def save_search(query, results):
    """
    Salva una ricerca e i suoi risultati nel database.
    
    Args:
        query: La query di ricerca
        results: Lista di dict con {title, url, description, position}
    
    Returns:
        ID della ricerca salvata
    """
    conn = get_connection()
    cursor = conn.cursor()

    cursor.execute(
        "INSERT INTO searches (query, results_count) VALUES (?, ?)",
        (query, len(results))
    )
    search_id = cursor.lastrowid

    for result in results:
        cursor.execute(
            "INSERT INTO results (search_id, title, url, description, position) VALUES (?, ?, ?, ?, ?)",
            (search_id, result.get("title", ""), result.get("url", ""), 
             result.get("description", ""), result.get("position", 0))
        )

    conn.commit()
    conn.close()
    return search_id


def get_history(limit=50, offset=0):
    """
    Recupera lo storico delle ricerche.
    
    Args:
        limit: Numero massimo di ricerche da restituire
        offset: Offset per paginazione
    
    Returns:
        Lista di ricerche con risultati
    """
    conn = get_connection()
    cursor = conn.cursor()

    cursor.execute(
        "SELECT * FROM searches ORDER BY created_at DESC LIMIT ? OFFSET ?",
        (limit, offset)
    )
    searches = [dict(row) for row in cursor.fetchall()]

    for search in searches:
        cursor.execute(
            "SELECT * FROM results WHERE search_id = ? ORDER BY position",
            (search["id"],)
        )
        search["results"] = [dict(row) for row in cursor.fetchall()]

    conn.close()
    return searches


def get_search_by_id(search_id):
    """Recupera una ricerca specifica per ID."""
    conn = get_connection()
    cursor = conn.cursor()

    cursor.execute("SELECT * FROM searches WHERE id = ?", (search_id,))
    search = cursor.fetchone()

    if search is None:
        conn.close()
        return None

    search = dict(search)
    cursor.execute(
        "SELECT * FROM results WHERE search_id = ? ORDER BY position",
        (search_id,)
    )
    search["results"] = [dict(row) for row in cursor.fetchall()]

    conn.close()
    return search


def delete_search(search_id):
    """Elimina una ricerca e i suoi risultati."""
    conn = get_connection()
    cursor = conn.cursor()
    cursor.execute("DELETE FROM searches WHERE id = ?", (search_id,))
    affected = cursor.rowcount
    conn.commit()
    conn.close()
    return affected > 0


def clear_history():
    """Elimina tutto lo storico."""
    conn = get_connection()
    cursor = conn.cursor()
    cursor.execute("DELETE FROM results")
    cursor.execute("DELETE FROM searches")
    conn.commit()
    conn.close()


def get_stats():
    """Restituisce statistiche generali."""
    conn = get_connection()
    cursor = conn.cursor()

    cursor.execute("SELECT COUNT(*) as total_searches FROM searches")
    total_searches = cursor.fetchone()["total_searches"]

    cursor.execute("SELECT COUNT(*) as total_results FROM results")
    total_results = cursor.fetchone()["total_results"]

    cursor.execute("""
        SELECT query, COUNT(*) as count 
        FROM searches 
        GROUP BY query 
        ORDER BY count DESC 
        LIMIT 5
    """)
    top_queries = [dict(row) for row in cursor.fetchall()]

    conn.close()
    return {
        "total_searches": total_searches,
        "total_results": total_results,
        "top_queries": top_queries
    }
