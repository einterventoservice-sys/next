"""
SearchBot — Server Flask Principale
API REST per la ricerca Google con dashboard web.
"""

import os
import sys
import logging
from datetime import datetime

from flask import Flask, request, jsonify, send_from_directory

from database import init_db, save_search, get_history, get_search_by_id, delete_search, clear_history, get_stats
from scraper import search_google

# Configurazione logging
logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [%(levelname)s] %(name)s: %(message)s",
    handlers=[
        logging.StreamHandler(sys.stdout),
        logging.FileHandler("searchbot.log", encoding="utf-8"),
    ]
)
logger = logging.getLogger("SearchBot")

# Inizializza Flask
app = Flask(__name__, static_folder="static", static_url_path="")

# Configurazione
app.config["JSON_AS_ASCII"] = False
app.config["JSON_SORT_KEYS"] = False


# ─── Inizializzazione ────────────────────────────────────────────────

@app.before_request
def before_first_request():
    """Inizializza il database alla prima richiesta."""
    if not hasattr(app, "_db_initialized"):
        init_db()
        app._db_initialized = True
        logger.info("Database inizializzato")


# ─── Routes Statiche ─────────────────────────────────────────────────

@app.route("/")
def index():
    """Serve la dashboard principale."""
    return send_from_directory("static", "index.html")


# ─── API Ricerca ──────────────────────────────────────────────────────

@app.route("/api/search", methods=["POST"])
def api_search():
    """
    Esegue una ricerca su Google.
    
    Body JSON:
        query (str): La query di ricerca
        num_results (int, opzionale): Numero di risultati (default: 10, max: 20)
        lang (str, opzionale): Lingua (default: "it")
    
    Returns:
        JSON con risultati della ricerca
    """
    data = request.get_json()

    if not data or not data.get("query"):
        return jsonify({"success": False, "error": "Query mancante"}), 400

    query = data["query"].strip()
    if len(query) < 2:
        return jsonify({"success": False, "error": "Query troppo corta (min 2 caratteri)"}), 400

    if len(query) > 200:
        return jsonify({"success": False, "error": "Query troppo lunga (max 200 caratteri)"}), 400

    num_results = min(int(data.get("num_results", 10)), 20)
    lang = data.get("lang", "it")

    logger.info(f"Ricerca: '{query}' (num={num_results}, lang={lang})")

    # Esegui la ricerca
    search_result = search_google(query, num_results=num_results, lang=lang)

    if search_result["success"]:
        # Salva nello storico
        search_id = save_search(query, search_result["results"])
        logger.info(f"Ricerca #{search_id}: {len(search_result['results'])} risultati trovati ({search_result['method']})")

        return jsonify({
            "success": True,
            "search_id": search_id,
            "query": query,
            "results": search_result["results"],
            "results_count": len(search_result["results"]),
            "method": search_result["method"],
            "timestamp": datetime.utcnow().isoformat(),
        })
    else:
        logger.warning(f"Ricerca fallita: '{query}' — {search_result['error']}")
        return jsonify({
            "success": False,
            "error": search_result["error"],
        }), 503


# ─── API Storico ──────────────────────────────────────────────────────

@app.route("/api/history", methods=["GET"])
def api_history():
    """
    Restituisce lo storico delle ricerche.
    
    Query params:
        limit (int): Numero massimo (default: 50)
        offset (int): Offset per paginazione (default: 0)
    """
    limit = min(int(request.args.get("limit", 50)), 100)
    offset = int(request.args.get("offset", 0))

    history = get_history(limit=limit, offset=offset)
    return jsonify({
        "success": True,
        "history": history,
        "count": len(history),
    })


@app.route("/api/history/<int:search_id>", methods=["GET"])
def api_get_search(search_id):
    """Restituisce una ricerca specifica."""
    search = get_search_by_id(search_id)
    if search is None:
        return jsonify({"success": False, "error": "Ricerca non trovata"}), 404
    return jsonify({"success": True, "search": search})


@app.route("/api/history/<int:search_id>", methods=["DELETE"])
def api_delete_search(search_id):
    """Elimina una ricerca dallo storico."""
    deleted = delete_search(search_id)
    if deleted:
        return jsonify({"success": True, "message": "Ricerca eliminata"})
    return jsonify({"success": False, "error": "Ricerca non trovata"}), 404


@app.route("/api/history/clear", methods=["DELETE"])
def api_clear_history():
    """Elimina tutto lo storico."""
    clear_history()
    return jsonify({"success": True, "message": "Storico eliminato"})


# ─── API Statistiche ─────────────────────────────────────────────────

@app.route("/api/stats", methods=["GET"])
def api_stats():
    """Restituisce statistiche generali."""
    stats = get_stats()
    return jsonify({"success": True, "stats": stats})


# ─── Health Check ─────────────────────────────────────────────────────

@app.route("/api/health", methods=["GET"])
def api_health():
    """Health check per monitoraggio."""
    return jsonify({
        "status": "ok",
        "service": "SearchBot",
        "timestamp": datetime.utcnow().isoformat(),
    })


# ─── Error Handlers ──────────────────────────────────────────────────

@app.errorhandler(404)
def not_found(e):
    return jsonify({"success": False, "error": "Endpoint non trovato"}), 404


@app.errorhandler(500)
def server_error(e):
    logger.error(f"Errore server: {e}")
    return jsonify({"success": False, "error": "Errore interno del server"}), 500


# ─── Main ─────────────────────────────────────────────────────────────

if __name__ == "__main__":
    init_db()
    logger.info("SearchBot avviato — http://0.0.0.0:5000")

    app.run(
        host="0.0.0.0",
        port=5000,
        debug=False,
    )
