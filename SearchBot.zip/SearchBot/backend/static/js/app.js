/**
 * SearchBot — Frontend Application Logic
 * Gestisce ricerche, storico, statistiche e interazioni UI.
 */

// ─── State ───────────────────────────────────────────────────────
const state = {
    currentTab: 'search',
    isSearching: false,
    lastQuery: '',
};

// ─── DOM Elements ────────────────────────────────────────────────
const $ = (sel) => document.querySelector(sel);
const $$ = (sel) => document.querySelectorAll(sel);

const els = {
    searchInput: $('#searchInput'),
    searchBtn: $('#searchBtn'),
    numResults: $('#numResults'),
    searchLang: $('#searchLang'),
    loadingContainer: $('#loadingContainer'),
    loadingSubtext: $('#loadingSubtext'),
    resultsArea: $('#resultsArea'),
    resultsGrid: $('#resultsGrid'),
    resultsTitle: $('#resultsTitle'),
    resultsMeta: $('#resultsMeta'),
    errorContainer: $('#errorContainer'),
    errorText: $('#errorText'),
    exportBtn: $('#exportBtn'),
    copyBtn: $('#copyBtn'),
    retryBtn: $('#retryBtn'),
    historyList: $('#historyList'),
    clearHistoryBtn: $('#clearHistoryBtn'),
    statsGrid: $('#statsGrid'),
    statSearches: $('#statSearches'),
    statResults: $('#statResults'),
    statAvg: $('#statAvg'),
    topQueriesList: $('#topQueriesList'),
    toastContainer: $('#toastContainer'),
    bgParticles: $('#bgParticles'),
};

// ─── Initialize ──────────────────────────────────────────────────
document.addEventListener('DOMContentLoaded', () => {
    initParticles();
    initTabs();
    initSearch();
    initHistory();
    initExport();
    checkHealth();
});

// ─── Background Particles ────────────────────────────────────────
function initParticles() {
    const colors = ['rgba(99,102,241,0.3)', 'rgba(168,85,247,0.25)', 'rgba(236,72,153,0.2)'];
    for (let i = 0; i < 15; i++) {
        const particle = document.createElement('div');
        particle.className = 'particle';
        particle.style.cssText = `
            left: ${Math.random() * 100}%;
            width: ${2 + Math.random() * 4}px;
            height: ${2 + Math.random() * 4}px;
            background: ${colors[Math.floor(Math.random() * colors.length)]};
            animation-duration: ${10 + Math.random() * 20}s;
            animation-delay: ${Math.random() * 10}s;
        `;
        els.bgParticles.appendChild(particle);
    }
}

// ─── Tab Navigation ──────────────────────────────────────────────
function initTabs() {
    $$('.nav-tab').forEach(tab => {
        tab.addEventListener('click', () => {
            const tabName = tab.dataset.tab;
            switchTab(tabName);
        });
    });
}

function switchTab(tabName) {
    state.currentTab = tabName;

    // Update nav tabs
    $$('.nav-tab').forEach(t => t.classList.remove('active'));
    $(`.nav-tab[data-tab="${tabName}"]`).classList.add('active');

    // Update tab content
    $$('.tab-content').forEach(c => c.classList.remove('active'));
    $(`#tab${tabName.charAt(0).toUpperCase() + tabName.slice(1)}`).classList.add('active');

    // Load data for tab
    if (tabName === 'history') loadHistory();
    if (tabName === 'stats') loadStats();
}

// ─── Search ──────────────────────────────────────────────────────
function initSearch() {
    els.searchBtn.addEventListener('click', performSearch);
    els.searchInput.addEventListener('keydown', (e) => {
        if (e.key === 'Enter') performSearch();
    });
    els.retryBtn.addEventListener('click', performSearch);

    // Auto focus
    setTimeout(() => els.searchInput.focus(), 300);
}

async function performSearch() {
    const query = els.searchInput.value.trim();
    if (!query || query.length < 2) {
        showToast('Inserisci almeno 2 caratteri', 'error');
        els.searchInput.focus();
        return;
    }

    if (state.isSearching) return;
    state.isSearching = true;
    state.lastQuery = query;

    // UI: Show loading
    els.searchBtn.disabled = true;
    els.resultsArea.style.display = 'none';
    els.errorContainer.style.display = 'none';
    els.loadingContainer.style.display = 'block';

    const loadingTexts = [
        'Sto cercando su Google...',
        'Analizzando i risultati...',
        'Filtrando i contenuti migliori...',
    ];
    let textIndex = 0;
    const loadingInterval = setInterval(() => {
        textIndex = (textIndex + 1) % loadingTexts.length;
        els.loadingSubtext.textContent = loadingTexts[textIndex];
    }, 2000);

    try {
        const response = await fetch('/api/search', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
                query: query,
                num_results: parseInt(els.numResults.value),
                lang: els.searchLang.value,
            }),
        });

        const data = await response.json();

        clearInterval(loadingInterval);
        els.loadingContainer.style.display = 'none';

        if (data.success && data.results.length > 0) {
            renderResults(data);
        } else if (data.success && data.results.length === 0) {
            showError('Nessun risultato trovato per questa query. Prova con parole diverse.');
        } else {
            showError(data.error || 'Errore durante la ricerca.');
        }
    } catch (err) {
        clearInterval(loadingInterval);
        els.loadingContainer.style.display = 'none';
        showError('Errore di connessione al server. Verifica che il bot sia in esecuzione.');
        console.error('Search error:', err);
    } finally {
        state.isSearching = false;
        els.searchBtn.disabled = false;
    }
}

// ─── Render Results ──────────────────────────────────────────────
function renderResults(data) {
    els.resultsTitle.textContent = `Risultati per "${data.query}"`;
    els.resultsMeta.textContent = `${data.results_count} risultati · ${data.method}`;

    els.resultsGrid.innerHTML = '';

    data.results.forEach((result, index) => {
        const card = document.createElement('div');
        card.className = 'result-card';
        card.style.animationDelay = `${index * 0.06}s`;

        const domain = extractDomain(result.url);

        card.innerHTML = `
            <span class="result-position">#${result.position}</span>
            <h3 class="result-title">${escapeHtml(result.title)}</h3>
            <a href="${escapeHtml(result.url)}" target="_blank" rel="noopener noreferrer" class="result-url">
                <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                    <path d="M18 13v6a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V8a2 2 0 0 1 2-2h6"></path>
                    <polyline points="15 3 21 3 21 9"></polyline>
                    <line x1="10" y1="14" x2="21" y2="3"></line>
                </svg>
                ${escapeHtml(domain)}
            </a>
            <p class="result-description">${escapeHtml(result.description)}</p>
        `;

        els.resultsGrid.appendChild(card);
    });

    els.resultsArea.style.display = 'block';

    // Scroll to results
    setTimeout(() => {
        els.resultsArea.scrollIntoView({ behavior: 'smooth', block: 'start' });
    }, 100);

    // Store results for export
    state.lastResults = data;
    showToast(`${data.results_count} risultati trovati!`, 'success');
}

// ─── Error Display ───────────────────────────────────────────────
function showError(message) {
    els.errorText.textContent = message;
    els.errorContainer.style.display = 'block';
}

// ─── History ─────────────────────────────────────────────────────
function initHistory() {
    els.clearHistoryBtn.addEventListener('click', clearHistory);
}

async function loadHistory() {
    try {
        const response = await fetch('/api/history?limit=50');
        const data = await response.json();

        if (data.success && data.history.length > 0) {
            renderHistory(data.history);
        } else {
            els.historyList.innerHTML = `
                <div class="empty-state">
                    <div class="empty-icon">📭</div>
                    <p class="empty-text">Nessuna ricerca nello storico</p>
                    <p class="empty-subtext">Le tue ricerche appariranno qui</p>
                </div>
            `;
        }
    } catch (err) {
        console.error('History load error:', err);
        showToast('Errore nel caricamento dello storico', 'error');
    }
}

function renderHistory(history) {
    els.historyList.innerHTML = '';

    history.forEach((item, index) => {
        const el = document.createElement('div');
        el.className = 'history-item';
        el.style.animationDelay = `${index * 0.04}s`;

        const date = new Date(item.created_at).toLocaleString('it-IT', {
            day: '2-digit',
            month: 'short',
            year: 'numeric',
            hour: '2-digit',
            minute: '2-digit',
        });

        let previewHtml = '';
        if (item.results && item.results.length > 0) {
            previewHtml = item.results.slice(0, 5).map(r => `
                <div class="preview-result">
                    <div class="preview-result-title">${escapeHtml(r.title)}</div>
                    <a href="${escapeHtml(r.url)}" target="_blank" rel="noopener" class="preview-result-url">${escapeHtml(extractDomain(r.url))}</a>
                </div>
            `).join('');
        }

        el.innerHTML = `
            <div class="history-item-header">
                <span class="history-query">${escapeHtml(item.query)}</span>
                <div class="history-actions">
                    <button class="history-delete-btn" data-id="${item.id}" title="Elimina">
                        <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                            <line x1="18" y1="6" x2="6" y2="18"></line>
                            <line x1="6" y1="6" x2="18" y2="18"></line>
                        </svg>
                    </button>
                </div>
            </div>
            <div class="history-meta">
                <span>📅 ${date}</span>
                <span>📊 ${item.results_count} risultati</span>
            </div>
            <div class="history-results-preview">${previewHtml}</div>
        `;

        // Toggle expand
        el.addEventListener('click', (e) => {
            if (e.target.closest('.history-delete-btn') || e.target.closest('.preview-result-url')) return;
            el.classList.toggle('expanded');
        });

        // Delete handler
        const deleteBtn = el.querySelector('.history-delete-btn');
        deleteBtn.addEventListener('click', (e) => {
            e.stopPropagation();
            deleteHistoryItem(item.id);
        });

        els.historyList.appendChild(el);
    });
}

async function deleteHistoryItem(id) {
    try {
        const response = await fetch(`/api/history/${id}`, { method: 'DELETE' });
        const data = await response.json();
        if (data.success) {
            showToast('Ricerca eliminata', 'info');
            loadHistory();
        }
    } catch (err) {
        showToast('Errore durante l\'eliminazione', 'error');
    }
}

async function clearHistory() {
    if (!confirm('Sei sicuro di voler eliminare tutto lo storico?')) return;

    try {
        const response = await fetch('/api/history/clear', { method: 'DELETE' });
        const data = await response.json();
        if (data.success) {
            showToast('Storico eliminato', 'success');
            loadHistory();
        }
    } catch (err) {
        showToast('Errore durante l\'eliminazione', 'error');
    }
}

// ─── Statistics ──────────────────────────────────────────────────
async function loadStats() {
    try {
        const response = await fetch('/api/stats');
        const data = await response.json();

        if (data.success) {
            const stats = data.stats;
            animateNumber(els.statSearches, stats.total_searches);
            animateNumber(els.statResults, stats.total_results);

            const avg = stats.total_searches > 0
                ? Math.round(stats.total_results / stats.total_searches)
                : 0;
            animateNumber(els.statAvg, avg);

            renderTopQueries(stats.top_queries);
        }
    } catch (err) {
        console.error('Stats load error:', err);
    }
}

function animateNumber(element, target) {
    const duration = 800;
    const start = parseInt(element.textContent) || 0;
    const diff = target - start;
    const startTime = performance.now();

    function update(currentTime) {
        const elapsed = currentTime - startTime;
        const progress = Math.min(elapsed / duration, 1);
        const eased = 1 - Math.pow(1 - progress, 3); // easeOutCubic
        element.textContent = Math.round(start + diff * eased);

        if (progress < 1) {
            requestAnimationFrame(update);
        }
    }

    requestAnimationFrame(update);
}

function renderTopQueries(queries) {
    if (!queries || queries.length === 0) {
        els.topQueriesList.innerHTML = `
            <div class="empty-state small">
                <p class="empty-text">Nessun dato disponibile</p>
            </div>
        `;
        return;
    }

    els.topQueriesList.innerHTML = queries.map((q, i) => `
        <div class="top-query-item">
            <span class="top-query-rank">#${i + 1}</span>
            <span class="top-query-text">${escapeHtml(q.query)}</span>
            <span class="top-query-count">${q.count}×</span>
        </div>
    `).join('');
}

// ─── Export & Copy ───────────────────────────────────────────────
function initExport() {
    els.exportBtn.addEventListener('click', exportResults);
    els.copyBtn.addEventListener('click', copyResults);
}

function exportResults() {
    if (!state.lastResults) return;

    const data = state.lastResults;
    let text = `SearchBot — Risultati per "${data.query}"\n`;
    text += `Data: ${new Date().toLocaleString('it-IT')}\n`;
    text += `Risultati: ${data.results_count}\n`;
    text += `${'═'.repeat(60)}\n\n`;

    data.results.forEach(r => {
        text += `#${r.position} — ${r.title}\n`;
        text += `URL: ${r.url}\n`;
        text += `${r.description}\n\n`;
    });

    const blob = new Blob([text], { type: 'text/plain;charset=utf-8' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `searchbot_${data.query.replace(/\s+/g, '_').substring(0, 30)}.txt`;
    a.click();
    URL.revokeObjectURL(url);

    showToast('Risultati esportati!', 'success');
}

function copyResults() {
    if (!state.lastResults) return;

    const data = state.lastResults;
    let text = data.results.map(r =>
        `${r.title}\n${r.url}\n${r.description}`
    ).join('\n\n');

    navigator.clipboard.writeText(text).then(() => {
        showToast('Risultati copiati negli appunti!', 'success');
    }).catch(() => {
        showToast('Impossibile copiare', 'error');
    });
}

// ─── Health Check ────────────────────────────────────────────────
async function checkHealth() {
    try {
        const response = await fetch('/api/health');
        const data = await response.json();
        if (data.status === 'ok') {
            $('#statusDot').style.background = 'var(--accent-green)';
            $('#statusText').textContent = 'Online';
        }
    } catch {
        $('#statusDot').style.background = 'var(--accent-red)';
        $('#statusText').textContent = 'Offline';
    }
}

// ─── Toast Notifications ─────────────────────────────────────────
function showToast(message, type = 'info') {
    const toast = document.createElement('div');
    toast.className = `toast ${type}`;

    const icons = {
        success: '✅',
        error: '❌',
        info: 'ℹ️',
    };

    toast.innerHTML = `<span>${icons[type] || 'ℹ️'}</span> ${escapeHtml(message)}`;
    els.toastContainer.appendChild(toast);

    setTimeout(() => {
        toast.style.animation = 'toastSlideOut 0.3s ease-in forwards';
        setTimeout(() => toast.remove(), 300);
    }, 3500);
}

// ─── Utilities ───────────────────────────────────────────────────
function escapeHtml(text) {
    if (!text) return '';
    const div = document.createElement('div');
    div.textContent = text;
    return div.innerHTML;
}

function extractDomain(url) {
    try {
        const parsed = new URL(url);
        return parsed.hostname.replace('www.', '');
    } catch {
        return url;
    }
}
