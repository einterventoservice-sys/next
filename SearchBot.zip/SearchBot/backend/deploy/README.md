# 🔍 SearchBot — Guida Deploy su Debian Linux VDS

## Prerequisiti

- VDS con **Debian 11/12** (Bullseye/Bookworm)
- Accesso **root** o utente con `sudo`
- Almeno **512 MB RAM** e **1 GB disco**

---

## 🚀 Setup Automatico (Consigliato)

Il modo più semplice è usare lo script di setup automatico:

```bash
# 1. Carica i file sul VDS (da locale)
scp -r SearchBot/ root@TUO_IP_VDS:/tmp/

# 2. Connettiti al VDS
ssh root@TUO_IP_VDS

# 3. Esegui lo script di setup
cd /tmp/SearchBot/backend/deploy/
chmod +x setup.sh
bash setup.sh
```

Lo script farà tutto automaticamente:
- ✅ Installa Python 3, pip, dipendenze di sistema
- ✅ Crea un utente di servizio dedicato
- ✅ Copia i file in `/opt/searchbot/`
- ✅ Crea l'ambiente virtuale Python
- ✅ Configura il servizio systemd
- ✅ Apre la porta nel firewall (UFW)
- ✅ Avvia il bot

---

## 🔧 Setup Manuale

Se preferisci installare manualmente:

### 1. Installa dipendenze

```bash
sudo apt update
sudo apt install -y python3 python3-pip python3-venv python3-dev \
    libxml2-dev libxslt1-dev zlib1g-dev
```

### 2. Copia i file

```bash
sudo mkdir -p /opt/searchbot
sudo cp -r backend/* /opt/searchbot/
```

### 3. Crea ambiente virtuale

```bash
cd /opt/searchbot
sudo python3 -m venv venv
sudo ./venv/bin/pip install -r requirements.txt
```

### 4. Test rapido

```bash
cd /opt/searchbot
sudo ./venv/bin/python app.py
# Apri http://TUO_IP:5000 nel browser
```

### 5. Configura systemd

```bash
sudo cp deploy/searchbot.service /etc/systemd/system/
sudo mkdir -p /var/log/searchbot
sudo useradd --system --no-create-home searchbot
sudo chown -R searchbot:searchbot /opt/searchbot /var/log/searchbot
sudo systemctl daemon-reload
sudo systemctl enable searchbot
sudo systemctl start searchbot
```

### 6. Configura firewall

```bash
sudo ufw allow 5000/tcp
sudo ufw enable
```

---

## 📋 Comandi Utili

| Comando | Descrizione |
|---|---|
| `sudo systemctl status searchbot` | Stato del servizio |
| `sudo systemctl restart searchbot` | Riavvia il bot |
| `sudo systemctl stop searchbot` | Ferma il bot |
| `sudo systemctl start searchbot` | Avvia il bot |
| `sudo journalctl -u searchbot -f` | Log in tempo reale |
| `sudo journalctl -u searchbot --since today` | Log di oggi |

---

## 🌐 Accesso Dashboard

Dopo l'installazione, apri nel browser:

```
http://TUO_IP_VDS:5000
```

---

## 🔒 SSL con Nginx (Opzionale)

Per abilitare HTTPS con un dominio:

```bash
# Installa Nginx e Certbot
sudo apt install -y nginx certbot python3-certbot-nginx

# Configura Nginx come reverse proxy
sudo tee /etc/nginx/sites-available/searchbot << 'EOF'
server {
    listen 80;
    server_name tuodominio.com;

    location / {
        proxy_pass http://127.0.0.1:5000;
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto $scheme;
    }
}
EOF

# Attiva il sito
sudo ln -s /etc/nginx/sites-available/searchbot /etc/nginx/sites-enabled/
sudo nginx -t
sudo systemctl restart nginx

# Ottieni certificato SSL
sudo certbot --nginx -d tuodominio.com
```

---

## ⚠️ Note Importanti

- **Google Rate Limiting**: Il bot include rotazione User-Agent e delay randomici, ma per uso intensivo (>100 ricerche/giorno) è consigliabile integrare un proxy o usare la Google Custom Search API.
- **Backup Database**: Il database SQLite si trova in `/opt/searchbot/searchbot.db`. Puoi fare backup con: `cp /opt/searchbot/searchbot.db /backup/`
- **Aggiornamento**: Per aggiornare, carica i nuovi file e riavvia: `sudo systemctl restart searchbot`
