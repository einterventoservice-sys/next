#!/bin/bash
# ═══════════════════════════════════════════════════════════════
# SearchBot — Script di Setup Automatico per Debian Linux
# Installa tutte le dipendenze, crea l'ambiente virtuale,
# configura systemd e il firewall.
# ═══════════════════════════════════════════════════════════════

set -e

# Colori
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
PURPLE='\033[0;35m'
NC='\033[0m' # No Color

echo -e "${PURPLE}"
echo "╔═══════════════════════════════════════════╗"
echo "║       🔍 SearchBot — Setup Debian         ║"
echo "╚═══════════════════════════════════════════╝"
echo -e "${NC}"

# ─── Controlla se siamo root ──────────────────────────────────
if [ "$EUID" -ne 0 ]; then
    echo -e "${RED}❌ Esegui questo script come root: sudo bash setup.sh${NC}"
    exit 1
fi

# ─── Configurazione ──────────────────────────────────────────
INSTALL_DIR="/opt/searchbot"
SERVICE_USER="searchbot"
SERVICE_NAME="searchbot"
PORT=5000

echo -e "${BLUE}📦 Configurazione:${NC}"
echo "   Directory: $INSTALL_DIR"
echo "   Utente:    $SERVICE_USER"
echo "   Porta:     $PORT"
echo ""

# ─── 1. Aggiorna sistema e installa dipendenze ───────────────
echo -e "${YELLOW}[1/7] Aggiornamento sistema e installazione dipendenze...${NC}"
apt-get update -qq
apt-get install -y -qq python3 python3-pip python3-venv python3-dev \
    libxml2-dev libxslt1-dev zlib1g-dev \
    ufw curl > /dev/null 2>&1
echo -e "${GREEN}  ✅ Dipendenze sistema installate${NC}"

# ─── 2. Crea utente di servizio ──────────────────────────────
echo -e "${YELLOW}[2/7] Creazione utente di servizio...${NC}"
if id "$SERVICE_USER" &>/dev/null; then
    echo -e "${GREEN}  ✅ Utente $SERVICE_USER già esistente${NC}"
else
    useradd --system --no-create-home --shell /usr/sbin/nologin "$SERVICE_USER"
    echo -e "${GREEN}  ✅ Utente $SERVICE_USER creato${NC}"
fi

# ─── 3. Copia file del progetto ──────────────────────────────
echo -e "${YELLOW}[3/7] Installazione SearchBot...${NC}"
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
BACKEND_DIR="$(dirname "$SCRIPT_DIR")"

mkdir -p "$INSTALL_DIR"

# Copia file backend
cp "$BACKEND_DIR/app.py" "$INSTALL_DIR/"
cp "$BACKEND_DIR/scraper.py" "$INSTALL_DIR/"
cp "$BACKEND_DIR/database.py" "$INSTALL_DIR/"
cp "$BACKEND_DIR/requirements.txt" "$INSTALL_DIR/"
cp -r "$BACKEND_DIR/static" "$INSTALL_DIR/"

chown -R "$SERVICE_USER:$SERVICE_USER" "$INSTALL_DIR"
echo -e "${GREEN}  ✅ File copiati in $INSTALL_DIR${NC}"

# ─── 4. Crea ambiente virtuale e installa pacchetti Python ───
echo -e "${YELLOW}[4/7] Creazione ambiente virtuale Python...${NC}"
python3 -m venv "$INSTALL_DIR/venv"
"$INSTALL_DIR/venv/bin/pip" install --upgrade pip -q
"$INSTALL_DIR/venv/bin/pip" install -r "$INSTALL_DIR/requirements.txt" -q
chown -R "$SERVICE_USER:$SERVICE_USER" "$INSTALL_DIR"
echo -e "${GREEN}  ✅ Ambiente virtuale creato e pacchetti installati${NC}"

# ─── 5. Configura systemd ────────────────────────────────────
echo -e "${YELLOW}[5/7] Configurazione servizio systemd...${NC}"
cat > /etc/systemd/system/${SERVICE_NAME}.service << EOF
[Unit]
Description=SearchBot — Google Search Bot con Dashboard Web
After=network.target
Wants=network-online.target

[Service]
Type=exec
User=$SERVICE_USER
Group=$SERVICE_USER
WorkingDirectory=$INSTALL_DIR
ExecStart=$INSTALL_DIR/venv/bin/gunicorn \
    --bind 0.0.0.0:$PORT \
    --workers 2 \
    --timeout 60 \
    --access-logfile /var/log/searchbot/access.log \
    --error-logfile /var/log/searchbot/error.log \
    app:app
Restart=always
RestartSec=5
StandardOutput=journal
StandardError=journal
SyslogIdentifier=$SERVICE_NAME

# Sicurezza
NoNewPrivileges=true
ProtectSystem=strict
ProtectHome=true
ReadWritePaths=$INSTALL_DIR /var/log/searchbot
PrivateTmp=true

[Install]
WantedBy=multi-user.target
EOF

# Crea directory log
mkdir -p /var/log/searchbot
chown -R "$SERVICE_USER:$SERVICE_USER" /var/log/searchbot

systemctl daemon-reload
echo -e "${GREEN}  ✅ Servizio systemd configurato${NC}"

# ─── 6. Configura firewall ───────────────────────────────────
echo -e "${YELLOW}[6/7] Configurazione firewall (UFW)...${NC}"
ufw allow $PORT/tcp > /dev/null 2>&1 || true
echo -e "${GREEN}  ✅ Porta $PORT aperta nel firewall${NC}"

# ─── 7. Avvia il servizio ────────────────────────────────────
echo -e "${YELLOW}[7/7] Avvio SearchBot...${NC}"
systemctl enable "$SERVICE_NAME" > /dev/null 2>&1
systemctl start "$SERVICE_NAME"

# Verifica che sia partito
sleep 2
if systemctl is-active --quiet "$SERVICE_NAME"; then
    echo -e "${GREEN}  ✅ SearchBot avviato con successo!${NC}"
else
    echo -e "${RED}  ❌ Errore nell'avvio. Controlla: journalctl -u $SERVICE_NAME -f${NC}"
    exit 1
fi

# ─── Riepilogo ────────────────────────────────────────────────
echo ""
echo -e "${PURPLE}╔═══════════════════════════════════════════╗"
echo -e "║         🎉 Setup Completato!              ║"
echo -e "╚═══════════════════════════════════════════╝${NC}"
echo ""
echo -e "${GREEN}SearchBot è in esecuzione!${NC}"
echo ""

# Ottieni IP del server
SERVER_IP=$(hostname -I | awk '{print $1}')
echo -e "  🌐 Dashboard:  ${BLUE}http://${SERVER_IP}:${PORT}${NC}"
echo -e "  📁 Directory:   $INSTALL_DIR"
echo -e "  📋 Log:         /var/log/searchbot/"
echo ""
echo -e "${YELLOW}Comandi utili:${NC}"
echo "  sudo systemctl status searchbot    — Stato del servizio"
echo "  sudo systemctl restart searchbot   — Riavvia"
echo "  sudo systemctl stop searchbot      — Ferma"
echo "  sudo journalctl -u searchbot -f    — Log in tempo reale"
echo ""
